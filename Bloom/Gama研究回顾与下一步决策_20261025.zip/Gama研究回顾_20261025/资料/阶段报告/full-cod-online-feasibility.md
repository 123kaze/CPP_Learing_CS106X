# 完整 COD：真实后端、在线并发与正式回本验证

2026-10-12。真实数据库校准与在线并发已经完成。正式六臂是否完成见第4节；无论单点结果如何，强成本静态/CLBF、因果选择器及原创性门槛未过，不能称论文成立。
 
## 1. 真实后端与价格分层

SQLite3.45.3 数据库含300万已有成员、256B合成payload，WITHOUT ROWID/BLOB十进制ID键，文件1,011,994,624B。用冻结配置把999996条独立负样本分成Hold-only误查19780、target-only误查6509、共同误查11655，分别计费。未依据价格改变模型、阈值或测试集。

| SQLite 请求缓存/连接 | 省掉的误查 CPU μs/次 | 新增的误查 CPU μs/次 | 成员 CPU μs/次 |
|---:|---:|---:|---:|
| 256 KiB | 27.648–29.702 | 28.622–28.806 | 31.875–32.031 |
| 8192 KiB | 19.275–19.590 | 20.312–20.681 | 26.250–27.969 |

各负样本类以固定shuffle顺序重复到至少80k次，成员为跨全体300万的100k样本；两个相反类顺序，fresh native进程32MiB上限。缓存请求值不等于SQLite实际含开销cache bytes；后者有记录。OS读取API字节不是物理磁盘读，也不证明冷SSD成本。较大缓存降低价格，说明不能用偏小缓存制造维护收益。

8MiB下，按省掉/新增误查分别收费，每999996条负查询的毛CPU节省约0.247–0.255s。600秒×100k总请求/s×90%负查询的端点毛信用为13.318–13.786s。这个用于选择正式时长，不包含同步、fail-open、新插入后FPR变化、统计或真正在线选择器；不保证未来价格或服务净收益。

## 2. 最终在线顺序与内存

固定48树/16区域/每区域14152B/k8，阈值由25833776242110下调到14222276889309。一个BF区域原位清空并在回放期间fail-open；其他区域继续服务。Full则全部区域同时fail-open。模型和布局不变，逐区域机制是已知方法，不是本轮算法创新。

旧实现把SQLite commit放在过滤器锁内。最终实现先短锁建立覆盖，再在日志锁内提交DB；清空区域也需要日志锁，故不能在覆盖与提交之间删除覆盖。查询不拿日志锁，DB IO不占过滤器锁。历史IO/打分均在服务锁外，位操作与发布在锁内。[证明与限制](full-cod-online-proof.md)。

并发压力插入1028个原本fit-negative里的真实ID，作为数据库新成员，和独立测试负样本不相交。这是合成成员变更，不是天文对象真实类型变化或生产插入时间线。WAL/同步/日志追加与即时插入查询全部实测收费。

每个端点载荷为33600B模型+226432B位图+2048B公共预留=262080B。实测元数据对象240B。I/O/日志/SQL/线程临时内存计入另设32MiB进程工作集/Job commit配额，不能写成整个服务只占256KiB。参考BF在服务前由同一arena生成并写盘，服务期间未保留第二BF。

## 3. 最终并发功能验证

每组500000个请求，100个请求为1ms批次，90%独立负样本/10%跨300万成员随机抽取；5秒真实计划时长，写入从0.5秒起每5ms一个，迁移从1秒开始。短试验只用于语义与内存检查，不能用于回本判断。

| 方法 | fail-open查询 | 误查 | 迁移wall s | 整段CPU s | 峰值WS MiB |
|---|---:|---:|---:|---:|---:|
| hold | 0 | 14,302 | 0.000 | 4.218750 | 26.551 |
| full | 61,305 | 63,628 | 2.377 | 7.781250 | 26.527 |
| regions | 13,974 | 23,003 | 2.364 | 6.406250 | 26.539 |

三组在线成员FN/DB成员漏查/插入FN/全部最终成员FN/参考位图字节差均0；最终DB3001028行。独立解码150万逐查询flag，成员标签、接受/后端命中/降级计数与native结果一致，1/1024样本时间戳匹配批次deadline。CPU表为单次功能试验，不据此排名。

全球fail-open会使单线程查询后端积压；正式记录包含offered deadline后的排队/输入/服务时间，而非只测SQL函数。短样本显示这种风险，但只有489个延迟样本，不宣称可靠p95差异、无暂停或时延上界。暂存两个原顺序smoke的源码/日志，未覆盖最终写入顺序的结果不混入此表。

## 4. 正式600秒验证

冻结为Hold→Full→Regions与相反次序Regions→Full→Hold，每组600秒/6000万请求，总6组；两个SQLite连接各请求8MiB缓存，同一32MiB进程上限。源数据、模型和脚本/程序SHA在spec/sources记录。持久化全部查询flag与1/1024延迟样本，真正运行分钟级负载，未把逻辑volume称作真实时长。

相对Hold分别收费：实际服务CPU、分区准备1.828125s CPU（及1.2GB外部存储）、原始重评分/日志回放（已包含服务CPU），另列上一轮全240配置离线搜索4.5s CPU参考。初始化计时含独立参考位图/成员验证，是诊断费用；只单列，不让更便宜的目标参考构建给adaptive利润加分。已经部署的共同旧状态加载不作为此次操作的增量费用。不得再次重复加迁移CPU；381.6MB离线选择器尚不满足32MiB在线RAM。缓存Full等更强历史布局及其完整生命周期仍需作为投稿基线，不以RawFull/Regions差异主张贡献。

只在全部六个进程完成并独立解码后判断两种顺序是否取得净收益、是否大于运行噪声；一条成功不完成第二数据集、强静态CLBF、因果选择器或原创性门槛。

正式六个进程已全部完成，逐查询flag和采样时间戳已独立解码。以下为实测完整服务CPU；完整服务费用已经包含迁移，不再重复加迁移CPU。

| 次序 | 方法 | 误查数 | fail-open查询 | 完整服务CPU s | 峰值WS MiB |
|---:|---|---:|---:|---:|---:|
| 0 | hold | 1,725,103 | 0 | 384.937500 | 26.594 |
| 0 | full | 1,041,974 | 59,328 | 372.437500 | 26.625 |
| 0 | regions | 1,004,203 | 15,120 | 375.453125 | 26.828 |
| 1 | regions | 1,003,024 | 13,873 | 382.765625 | 26.602 |
| 1 | full | 1,045,390 | 63,179 | 377.765625 | 26.594 |
| 1 | hold | 1,725,102 | 0 | 385.234375 | 26.602 |

| 次序 | 方法 | 比Hold少的误查 | 扣分区准备后CPU节省 s | 再扣4.5s搜索参考后 s | 已记直接K的c* CPU μs/误查 |
|---:|---|---:|---:|---:|---:|
| 0 | full | 683,129 | 12.500000 | 8.000000 | 9.995 |
| 0 | regions | 720,900 | 7.656250 | 3.156250 | 12.029 |
| 1 | regions | 722,078 | 0.640625 | -3.859375 | 11.988 |
| 1 | full | 679,712 | 7.468750 | 2.968750 | 10.023 |

**c*范围：**这里的直接K只含迁移线程CPU、分区准备及4.5s离线搜索参考；ΔM是实际600秒误查差，已含fail-open负担。统计、历史布局的持续维护及完整在线选择器尚未实现，因此不是完整生命周期c*。新增与省掉的误查真实价格可能不同；不能把同价c*替代分层后端账本。该组件表与完整服务差分是两种账本，不将两者重复相加。
- full 两次完整服务CPU范围 372.437500–377.765625s；观察到的跨度 5.328125s，不是置信区间。
- hold 两次完整服务CPU范围 384.937500–385.234375s；观察到的跨度 0.296875s，不是置信区间。
- regions 两次完整服务CPU范围 375.453125–382.765625s；观察到的跨度 7.312500s，不是置信区间。

即使两个次序都观察到正差，也只能说明这个冻结oracle目标相对48树最低FPR Hold存在一次实测机会；还不能认定因果决策有效或胜过成本较低的初始静态配置。已锁定 plan/full-cod-static-cost-protocol.md，先检查0/1/2/4/8/12/24/48初始静态前缀的raw49查询成本，然后判断是否值得做低成本选择器。完整CLBF与更强cached Full及其生命周期仍待比较。

## 5. 证据与复现

数据库准备在checkpoint时发生一次表锁失败，现有300万行经count/quick_check恢复。原始整轮setup CPU/wall缺失，恢复7.73s不是完整setup费用；初始DB为所有方法共用fixture，不能据此声称完整生命周期费用已齐。第一次online编译的unused-variable警告也保留，未启动服务；最终编译无警告。

协议：plan/full-cod-online-protocol.md（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\plan\full-cod-online-protocol.md`；未随阅读包附带）。源码：准备与恢复（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_backend_prepare.py`；未随阅读包附带）、价格校准（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_backend_calibrate.cpp`；未随阅读包附带）、8MiB校准驱动（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_backend_strong_run.py`；未随阅读包附带）、[在线原型](../源码/full_cod_online.cpp)、运行（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_online_run.py`；未随阅读包附带）、独立解码（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_online_verify.py`；未随阅读包附带）、本报告生成（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_online_analyze.py`；未随阅读包附带）。原型源文件在正式运行完成前不得改动。

原始记录：DB准备（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-online\prepare.json`；未随阅读包附带）、准备失败（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-online\prepare-failure.json`；未随阅读包附带）、小缓存校准（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-online\calibration-results.json`；未随阅读包附带）、8MiB校准（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-online\cache-8m\results.json`；未随阅读包附带）、最终smoke（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-online\smoke-precover-8m\rows.json`；未随阅读包附带）、独立flag验证（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-online\smoke-precover-8m\verification.json`；未随阅读包附带）、正式协议与SHA（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-online\paced-precover-600s-8m\spec.json`；未随阅读包附带）。

复现命令均在round2目录，Python E:\Conda\python.exe。先准备/恢复fixture→校准→full_cod_backend_strong_run.py→full_cod_online_run.py --smoke --cache-8m→full_cod_online_verify.py→冻结price-screen→full_cod_online_run.py --cache-8m。全部正式终态后运行 full_cod_online_verify.py paced-precover-600s-8m，再运行 full_cod_online_analyze.py。驱动拒绝覆盖已有结果，须优先检查实时工具handle与process.json，不能因观察超时重启。
