# Independent prior-art and proof review

Reviewed: 2026-10-10. Scope: the Round 2 protocol and a bounded-memory LBF migration prototype. This is a feasibility review, not a novelty certificate or submission approval. No code was changed by this reviewer.

**Decision:** a one-spare rolling rebuild is a useful correctness and memory baseline. Existing evidence does not establish it as a publishable new algorithm. The immediate experimental question is whether it gives an end-to-end advantage after charging replay layout, reserved capacity, synchronization and query degradation.

## Evidence-to-claim map

| Source | Inspected evidence | Supported claim / intended use | Limit |
|---|---|---|---|
| Bhattacharya, Bedathur, Bagchi, *Adaptive Learned Bloom Filters under Incremental Workloads*, CoDS COMAD 2020, DOI 10.1145/3371158.3371171 | [Author PDF](https://www.cse.iitd.ac.in/~srikanta/publication/codscomad-20-b/codscomad-20-b.pdf), PDF pp. 2–4, especially §3.3.3 | IA-LBF keeps its classifier and inserts classifier-rejected new members into DPBF. This is the named dynamic LBF comparator. | It trades additional index space for adaptation; it is not a fixed-peak-RAM migration protocol. |
| Negi et al., *Dynamic Partition Bloom Filters*, extended abstract, 2019 | [Primary preprint](https://arxiv.org/pdf/1901.06493), Definitions 2.2–2.4, pp. 3–5 | DPBF has a populated finest-level BF map and a compressed query tree. This distinguishes it from a list of BFs or fixed shards. | An extended abstract, not an implementation specification with all concurrent update details. |
| E. Sidirourgos, *Space efficient indexes for the big data era*, thesis, 2014, Chapter 3 | [Institutional PDF](https://ir.cwi.nl/pub/22532/22532D.pdf), printed pp. 57–69; PDF pp. 59–71; §3.5.1 / Algorithm 3.3 | Splitting filters over hash buckets or tree ranges, resizing individual filters and replaying only their covered storage are established techniques. Cite before claiming partitioned partial rebuild novelty. | The inspected description does not prove a strict transient-allocation bound. The chapter identifies related work with Per-Åke Larson as submitted at thesis printing, not as an accepted journal article. |
| US10795872B2, *Incremental bloom filter rebuild for B+ trees under multi-version concurrency control* | [Primary patent text](https://patents.google.com/patent/US10795872B2/en), descriptions of Figs. 3B–3D and 5, claims 1–4 | Old-filter service, incremental population of another BF during GC, checkpoints and insertion catch-up precede this project. | It creates a second BF; it is not evidence of a one-budget peak guarantee. This is technical prior-art comparison, not a legal opinion. |
| Zhu et al., *Mnemosyne*, PACMMOD 2025 | [Author PDF](https://cs-people.bu.edu/mathan/publications/pacmmod25-zhu.pdf), paragraph “BF Reconstruction During Flushes and Compactions” | Its RocksDB integration applies new allocations to files produced by flush/compaction; other existing filters remain unchanged. This is a useful deferred-maintenance comparator. | Immediate migration of a deployed LBF is a different execution problem. |
| Almeida et al., *Scalable Bloom Filters*, 2007 | [Author-hosted PDF](https://gsd.di.uminho.pt/members/cbm/ps/dbloom.pdf), construction and conclusion | Increasing filter sizes and progressively tighter error targets support set growth. | The memory allocation grows; a hard cap requires an explicitly disclosed policy. |

The thesis also allocates filter memory using observed access frequencies. Therefore “split into regions, rebuild one region, prioritize hot regions” is insufficient novelty by itself. Neither a patent nor an older thesis can be ignored merely because it is outside recent learned-filter conference papers.

Searches included exact IA-LBF/DPBF titles, their code references, incremental BF rebuild, peak-memory BF rebuild, and the named patent. This search was targeted, not exhaustive. Not finding an exact phrase is not evidence that a method is new.

## Faithful dynamic baseline recommendation

Implement **IA-LBF with DPBF**, or explicitly label an approximation. The necessary DPBF details from the preprint are:

- Fix a namespace, a partition-tree depth and a unit-BF capacity. The stated construction ties finest partition cardinality to capacity.
- Keep populated finest-level BFs in puBFMap; keep a compressed tree whose leaf BF covers at most the capacity.
- Query the single routed compressed-tree leaf. Insertions and splits must preserve the finest-level information; do not recreate missing children from a mixed parent bitmap.
- Count both structures. The paper allows up to twice the number of populated finest-level BFs, plus tree/map metadata.

A practical fixed-depth, empirically capacity-limited implementation may be useful, but differs from the paper's universal namespace-capacity construction. State that difference. A 64-bit hash namespace does not automatically provide compact finest-level storage. Mapping keys to compact IDs needs its own lookup structure or introduces hash collisions; both affect the accounting.

**Implementation decision for this project:** report the measured unconstrained IA-LBF footprint and the first budget violation. Under a cap, preserve correctness by declaring the target configuration infeasible, using a disclosed fail-open fallback, or accepting degraded FPR after stopping expansion. Dropping old filters is invalid. An append-only collection with OR queries is a DBF-backed LBF adaptation, not IA-LBF. A geometrically tightened layered comparator should be called an SBF-backed LBF adaptation only after implementing and checking the corresponding policy.

The baseline must use the same frozen classifier and train/validation split. Sweep its capacity/FPR parameters on validation data; otherwise a deliberately poor DPBF configuration can exaggerate the proposed method's advantage. Also include a pure BF and a fixed-size LBF accepting all inserts without rebuilding. Their low maintenance cost matters even when their final FPR is worse.

## Correctness statements and proofs

The following arguments are this review's derivations. They are about insert-only service with immutable key features and a fixed deterministic model unless stated otherwise. They do not cover recovery after a crash.

Let S be committed members, f the model score, and H(x) the set of bit positions tested by a fixed BF. Let

\[
A_\tau=\{x\in S:f(x)\leq\tau\},\qquad
Q_\tau(x)=[f(x)>\tau]\lor B(x).
\]

**Coverage theorem.** Zero false negatives holds exactly when every x in A_tau is accepted by B. Proof: model-accepted members already return true; model-rejected members return B(x). Inserting every member of A_tau is sufficient, but is not necessary because accidental bit collisions can also cover a key.

**Threshold increase.** For tau1 > tau0, let D = {x in S: tau0 < f(x) <= tau1}. If B0 is exactly the OR of H(x) over A_tau0, then

\[
B_0\lor\bigvee_{x\in D}H(x)
=\bigvee_{x\in A_{\tau_1}}H(x).
\]

Thus in-place additions and a full replay yield identical bitmaps when m, k and hashes are unchanged. Complete D's coverage before publishing tau1. This proves equality, not a discovery-time speedup. Without an index or cached scores, identifying D can still require reading and scoring every historical key.

**Threshold decrease.** If tau1 < tau0, A_tau1 is a subset of A_tau0; retaining B0 is safe immediately. For the same target threshold and hashes, the freshly built bitmap is a bitwise subset of B0. Consequently the fresh target accepts no more negatives than reuse does. This comparison is at the same target threshold; decreasing the threshold itself need not lower the overall LBF FPR.

**One-spare rebuild.** Route every key deterministically to one of r disjoint shards. Let each shard own s bitmap bytes; preallocate r+1 blocks, and use one as scratch. Rebuild the chosen shard while queries use its old block. Include every pre-migration committed member eligible under its target threshold and every concurrently committed eligible insert. Publish its target descriptor only after that condition holds. Every query sees either the old valid descriptor or the new valid descriptor, so zero-FN follows shard by shard. Reuse the retired block as the next scratch only after its old readers have finished.

With fixed model bytes M and bounded metadata/buffers W, this algorithm owns at most

\[
M+(r+1)s+W
\]

bytes for the counted objects. Under total cap C, active bitmap storage is at most r(C-M-W)/(r+1), before integer rounding. The spare is reserved from the original budget. Comparing against a baseline with the same active bits measures migration cost; comparing all algorithms under the same cap measures practical utility. Both comparisons are useful and answer different questions.

For variable old sizes a_i, new sizes b_i and schedule pi, a build-before-retire implementation must satisfy at every step t:

\[
M+W+\sum_{j<t}b_{\pi(j)}
 +\sum_{j\geq t}a_{\pi(j)}
 +b_{\pi(t)}\leq C.
\]

Endpoint feasibility alone does not imply this transient condition. A fixed spare must fit every new block. Storing old and new model instances adds both sizes until all shards and readers have stopped using the old model.

## Concurrency conditions that must be checked in code

1. The query reads a consistent shard descriptor: model identity, threshold, bitmap address, m and k. Publishing a global threshold before all affected shards are ready is unsafe for increases.
2. A writer prepares coverage in the live block and the active replacement, when needed, before making its member visible. BF updates after member commit leave a false-negative interval.
3. Start dual writes before fixing the replay snapshot high-water mark, or provide a proven catch-up log. Snapshot-then-enable without catch-up loses inserts in the gap.
4. Bitmap read/modify/write must use atomics or compatible locks. A non-atomic C++ reader racing with a writer is undefined behavior even if all logical changes only set bits.
5. Pointer publication does not prove reclamation safety. A shard mutex held throughout lookup can make immediate reuse safe. With epochs or hazards, unreclaimed old blocks consume memory and can invalidate the one-spare bound.
6. A lock held for a disk read or entire shard replay may block that shard for the whole migration. “No global pause” is weaker than bounded query latency. Measure wait time and worst observed latency.
7. Full-rebuild and partial cases must use the same committed insertion population when endpoint equality is asserted. Different completion times must not produce different endpoint sets without explicit normalization.

Exhaustive post-run membership checks and online committed-member checks are necessary evidence, but cannot prove correctness for all schedules. The proof must match the implemented synchronization.

## What cannot be claimed as a lower bound

There is no universal impossibility result for “zero-FN + fixed memory + queries continue”: always returning true satisfies all three. A useful problem statement also constrains query quality, backend work, or cumulative excess false positives during migration.

Nor is “rebuild always needs double memory” true. One-spare shards, rebuilding an affected region while that region fails open, exact counters with sufficient extra representation, or an already indexed replay store are counterexamples under their respective assumptions.

An ordinary bitmap does lose deletion information. A two-bit, one-hash counterexample makes this precise. Let low-score keys a and c map respectively to bits 0 and 1, and high-score keys b and d map respectively to bits 0 and 1. Initial sets {a,b,d} and {c,b,d} have the same bitmap 11, the same size and the same departing set {b,d} after a threshold decrease. Their clean target bitmaps are 10 and 01. An algorithm given only the old bitmap, set counts and departing keys cannot distinguish the instances. It therefore cannot always compute the exact clean bitmap without additional information.

This indistinguishability argument does not by itself establish Omega(N) disk IO for every algorithm. A scan lower bound must specify an unindexed input model, what scores or memberships were retained, allowed bit-level summaries, and whether exact target-bitmap equality or only an FPR bound is required. Sorted score indexes, exact counters, perfect classifiers and unchanged target bitmaps defeat careless universal statements.

If every shard is rebuilt and its keys are stored in disjoint replay files, the total historical replay is still the entire set. A one-spare schedule saves transient BF storage; it does not automatically save IO or model scoring. Selectively rebuilding a subset can reduce replay only if locating those keys is cheap, and then the resulting state must be compared at equal query quality or reported as an explicit quality/work tradeoff.

## Next falsification experiments and publication gate

Use the current native prototype to measure these cases before extending it:

- Global threshold decrease: full rebuild and rolling rebuild should have identical endpoints with all-shard replay. The expected advantage is memory feasibility and service quality; lower CPU/IO remains an empirical question.
- Local maintenance: change one or a few regions, and give full rebuild access to the same preexisting replay layout. Charge layout creation, insert maintenance and persistent bytes. Report amortization across repeated changes.
- Vary shard count under the same total cap. Measure the spare reservation's initial-FPR penalty, replay seeks, locks, p99 query latency and cumulative extra backend requests.
- Compare hold, fail-open rebuild, rolling rebuild and an honestly named dynamic comparator at equal cap and final FPR. Include infeasible outcomes rather than allocating outside the budget.
- Repeat with Gama-selected model/BF allocations, including cases where the model changes. If the best model size does not change, keep that negative result and restrict the claimed application.

A defensible research gap could be an experimentally demonstrated, migration-aware optimization with a provable quality/work bound under an explicit peak allocation budget. That gap is presently a hypothesis. Fixed-shard rolling rebuild alone, fixed-model threshold updates alone, or superiority to an infeasible double-buffer baseline do not satisfy it.

## Verification record and open checks

Read the current Round 2 protocol. Opened the DPBF preprint, author IA-LBF publication page, institutional thesis and patent source. The web extractor repeatedly timed out on the IA-LBF PDF; a direct Python urllib fetch piped to pdftotext successfully extracted PDF pp. 2–4, including §3.3.3. No downloaded paper was written into the repository by this reviewer.

Additional primary PDFs opened: Mnemosyne and Scalable Bloom Filters. Direct urllib downloads piped to pdftotext verified the specific text recorded in the evidence map after in-page web searches failed. The direct extraction process exited successfully.

Open: executable IA-LBF reproduction; cold/storage-bound workloads; end-to-end backend latency rather than only filter CPU; multiple datasets; model-changing migration; crash recovery; a stronger novelty search after a concrete algorithmic result exists. These are publication gaps, not reasons to stop the current executable feasibility study.

## Native implementation review

Reviewed migrate.cpp snapshot SHA256 20e01ed84edc0791fcd6c7c55846b49be5a4060454e7ae97dcefcb9552bf2ad8, plus prepare.py and run_experiments.py. Later revisions require their own verification. No migration code was edited by this reviewer.

The journal-watermark protocol closes the previously reported pre-begin insertion gap. The writer holds journal.mu across append, flush, filter insertion and publication of the inserted count. The migration holds the same mutex across begin and watermark capture. Thus pre-begin commits are in the bounded journal prefix; later commits are covered by live or dual writes. The common lock order is journal then shard; query, replay and finish take only a shard lock. Query retains that lock through its bitmap read, so after finish exchanges a block the old block has no remaining readers and can safely become scratch. Full in-place uses fail-open while rebuilding, and updates the live target block before each insert returns. Subject to fixed input files and successful IO, this inspection found no remaining zero-FN counterexample in those paths.

Endpoint checking is substantive: after joining workers, the code constructs each target shard independently and compares every word. It is stronger than checksum equality. The common final insertion file normalizes the endpoint set despite different migration durations. The model-score error gate in this snapshot covers history only; it does not independently compare LightGBM references on negatives and future inserts. Endpoint reconstruction uses the native scorer again, so it does not fill that separate inference-validation gap.

Memory claims need three distinct labels. Filter-state bytes include native model capacity, all bitmap slots and sizeof metadata, but exclude allocator overhead, replay and journal buffers, worker stacks and runtime objects. The filter cap is a feasibility boolean computed after allocation, not allocation rejection: intentionally over-budget full-double references still run. The Windows Job limit is an enforced 32 MiB process commit limit, not a working-set bound. Microsoft documents ProcessMemoryLimit as committed virtual memory; PrivateUsage is private commit and PeakWorkingSetSize is a different measure ([Job limits](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information), [process counters](https://learn.microsoft.com/en-us/windows/win32/api/psapi/ns-psapi-process_memory_counters_ex)). The recorded process peak includes setup and service through worker completion, before the independent verification allocation; it is not an isolated migration-only peak.

The query p95/max fields aggregate the entire service interval, including time after migration while inserts finish. They must not be labeled migration-window latency. The interleaved negative/member loop repairs the earlier lack of member samples in some short migrations, but restarts both files when the negative stream ends; with 12,000 negatives and 30,000 historical members, its repeating online member sample is only the first 12,000. Final checks still visit all historical members. Migration counters also need positive sample counts before zero observed FN is meaningful. The percentile routine returns the first histogram boundary for zero observations; such rows should be displayed as missing latency.

Online process CPU and IO include query and insertion threads. The corresponding offline cases are therefore needed to identify migration work. Journal prefixes are rescanned once per rolling shard, correctly exposing potentially O(rI) extra journal work. The disk layout is an extra persistent representation; its building and maintenance costs remain necessary to any amortized benefit claim.

At this snapshot, migration uses a fixed four-tree low-FPR model with a common hash configuration, not a globally optimal model/segmentation/threshold combination. The earlier 1,792 versus 1,664 byte config mismatch was repaired in the inspected preparation source; the runner uses 1,664 bytes. This review does not certify subsequently generated result manifests or a completed experimental campaign.
