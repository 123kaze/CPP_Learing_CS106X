# Frozen-model threshold-decrease online prototype: correctness and costs

Scope: full_cod_online.cpp, fixed model48/raw49 finite features, fixed hash/mapping/k8, sixteen disjoint regions, old cutoff25833776242110→new14222276889309, one226432B bitmap. This is a proof of the implemented restricted mechanism, not a novel algorithm or evidence of profitability. Crash recovery, model/k/layout changes and arbitrary deletions are outside it.

## State invariant

For every committed member x in region r, at a filter decision's linearization point at least one is true: open[r]; f(x)>cut[r]; or all k hash bits for x are set in region r. Cut and open and BF bit writes/reads are protected by one service mutex; fixed model inference and history IO happen outside it. The model is immutable, so computing f before reacquiring the mutex cannot invalidate its value. Query hashes first and returns positive under the mutex if open; otherwise it scores outside the mutex and checks open/cut/BF again under the mutex. The second lock is that query's linearization point. A query takes no journal lock.

Initial state is built from all3000000 current members' frozen native scores at old cut, with every current member checked. Model-positive members satisfy the invariant directly; others had all bits inserted. The same raw49 model/quantization produced those cached native scores; prior independent parity sampling is separate evidence, not an all-row proof of LightGBM equivalence.

## Writer publication

The single writer computes immutable f(x) and hash, then takes journal mutex followed by service mutex. It appends and flushes the raw record to that region's external journal before the service lock. Under the short service lock it sets all bits if f(x)≤cut[r], releases the service lock, then commits the SQLite insert while retaining journal mutex. Queries can proceed during DB IO. Coverage therefore precedes commit. A migration's clearing epoch requires journal mutex and cannot begin between coverage and commit; an already-running migration only adds bits or publishes its already-installed target cutoff. At commit the member is covered, or its region remains open. A decision that linearized before coverage is earlier than membership publication. Early positive decisions for not-yet-committed keys are permissible false positives. Immediate post-insert service and DB queries are checked. DB insertion failures abort the experiment; no durable recovery protocol is claimed for an appended but uncommitted journal record or its extra BF bits.

## Region rebuilding

1. Take journal→service mutex, capture byte watermark w[r], clear the old region, set cut to target and open=true. Clearing happens atomically relative to service decisions and writers. Release both mutexes.
2. Replay every preexisting base member in the region and journal prefix[0,w[r]); only f(x)≤target-cut keys need their bits set. IO/scoring is outside service mutex, each OR insertion is inside it.
3. Under service mutex publish open=false. All keys committed before step1 are either base members or in the captured prefix. All keys committed after step1 are directly protected by the writer using target cut. Model-positive keys need no BF bits. OR insertions commute and duplicates are harmless. Thus the invariant holds at publication.

Other regions continue under their old/target cutoff until separately rebuilt. There is one allocated region bitmap throughout, so this mechanism reuses storage but not erased bit contents. It revisits every base key through the prepared shard files. It does not claim partial historical replay or score-band-only deletion. The global Full variant performs step1 for all regions, one base scan and all captured journal prefixes, then publishes all together; the same proof applies with all regions open in the interval.

## Memory and accounting

Fixed node/root payload33600B + BF226432B + declared control reserve2048B =262080B≤262144B. sizeof(Live49)+sizeof(Model)=240B in executed build, inside the reserve. Each live endpoint has one BF; before service, that same arena builds and writes the expected final reference, then is reused for the old state. Final reference comparison uses a one-byte streaming buffer; no second BF is allocated. Inference/query records, SQL caches, stream/journal/log buffers, runtime/threads count toward the32MiB process working-set/Job commit limits rather than the filter-core reserve. These are distinct budgets, not an assertion that all RAM fits256KiB.

Extra history layout is a1.2GB disk copy plus16 directory paths and sixteen16384B output buffers. Its measured preparationCPU1.828125s must be charged to IndexedRegions. Journal append storage is411200B for1028 inserts; prefix rereads are measured, not assumed free. Model scoring on every replay key is measured inside migration. DB/query flags/sample logging costs are included in serving CPU; initial reference/old-BF creation is recorded separately and uses cache scores, not claimed as a deployment-free initialization.

## Scope of current tests

The five-second semantic smoke uses500000 paced queries per arm with whole-member random seeks and sequential independent negatives,1028 inserts crossing migration. It checks complete initial/final members, inserted-key immediate coverage, recorded flags and exact expected final BF bytes. Success verifies those executions, not arbitrary scheduling, bounded query delay, hardware-independent CPU benefit, or an online decision algorithm. Queries may briefly wait for bitmap service mutex; open regions fail open to a real DB. Earlier smoke/smoke-8m snapshots committed DB under service lock; they are preserved and do not verify the final precover ordering. No pause-free latency guarantee or crash-safety proof.
