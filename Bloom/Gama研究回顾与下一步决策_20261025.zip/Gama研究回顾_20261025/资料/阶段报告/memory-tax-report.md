# 统计目录内存与自适应收益：受控预算分解

2026-10-11。本轮接续 [oracle 回本验证](oracle-feasibility-report.md)。完成固定模型的容量/k 分解和完整 COD 原始文件准备检查；没有新在线算法或可投稿贡献声明。

## 1. COD 的上一轮反转主要来自 BF 空间

固定此前静态阈值 2566043879964、相同模型8、16区域、相同 hash recipe，12m 查询的四格结果如下。增大位图包含必要的取模映射变化，不能解释为同一位图上的纯粹追加位。

| 区域位图 | k=8 | k=7 |
|---|---:|---:|
| 1536 B（支付1584 B目录） | 145317 | 145178 |
| 1632 B（静态无目录） | 127999 | 125934 |

沿“先增加位图空间，再改 k”顺序，17318 次改进来自容量/取模变化，2065 来自 k。反向顺序为139和19244。两种顺序平均归因是空间18281、k1102，总计19383；这只是明确的算术归因，不是普遍因果比例或新定理。

## 2. 放宽阈值族后，内存费用仍能超过 oracle 收益

同一45k成员、URL model1/COD model8、1008 B控制预留、16区域。枚举16/32/64KiB、目录预留0/实际值（URL336/COD1584 B）、全部已有14/66个阈值、k=1..16。共7680个配置，每个完整检查45000成员FN=0。全部1280个32KiB零预留配置与上一轮独立搜索的加权计数一致。

两阶段 oracle 使用未来信息，免费在半程切换阈值，每个阶段内保持阈值不变，且全程保持 k 和位图布局不变。它可以下调并瞬时得到干净新BF，所以不是已实现的Partial，也不是阶段内任意切换策略的性能下界。静态也用整条轨迹择优；两边都是离线机会控制。请求包含10.8m负查询；负查询两组比例9:1→1:9。

**可用内存无需填满。** 无目录 oracle 和静态可以仿用任何已测试、基础状态不超预算的较小位图，不必支付目录费用。支付目录的 oracle 则从“基础状态+目录≤预算”的同一已测试族选布局。这避免把最大填充位图误当经验全局最优。

| 数据集 / KiB | 无目录最佳静态 S | 无目录免费 oracle O0 | 支付目录免费 oracle Or | 自适应价值 V=S−O0 | 目录导致的机会损失 L=Or−O0 | 最终节省 V−L |
|---|---:|---:|---:|---:|---:|---:|
| COD /16 | 772184 | 699092 | 845370 | 73092 | 146278 | **−73186** |
| COD /32 | 125934 | 114602 | 132699 | 11332 | 18097 | **−6765** |
| COD /64 | 12820 | 11966 | 13259 | 854 | 1293 | **−439** |
| URL /16 | 546525 | 489791 | 514180 | 56734 | 24389 | **32345** |
| URL /32 | 71662 | 57999 | 57999 | 13663 | 0 | **13663** |
| URL /64 | 2890 | 2890 | 3248 | 0 | 358 | **−358** |

COD在三个预算下均失败；即使进一步让oracle按阶段免费改变k和布局，在本轮已测试族内也分别比静态多65297/5389/78次误查。允许在阶段内逐请求改变状态、更多模型或未测试布局不受本结论覆盖。

URL32KiB的最优oracle采用k=8，优于此前已部署k=7族。**上一轮41–48us的组件收费回本点不适用于这个新k8族**，没有据此声称新配置已取得端到端净收益。

### 为什么必须允许空闲 RAM？

若强制无目录oracle填满至1936 B/区域，URL32KiB得到59964次误查；1920 B较小布局却只有57999。取模改变后的有限样本FPR并不单调。无目录控制也应能选1920 B，将差值解释为目录带来收益会混淆比较族。嵌套候选集合修正后，URL32KiB的目录机会损失为0，并非负1965。

![预算与目录预留](../图片/memory-tax-memory-tax.png)

## 3. 可证明的部分与不能声称的部分

令C是某固定物理预算下已测试的无目录布局族，C_R是支付R字节目录后仍可行的子族。对两阶段负查询定义精确代价q_p(c,τ)，布局c含模型、k和位图尺寸。阈值只能取已有边界：

\[
S=\min_{c\in C,\tau}\sum_{p=0}^1q_p(c,\tau),\quad
O_0=\min_{c\in C}\sum_{p=0}^1\min_\tau q_p(c,\tau),\quad
O_R=\min_{c\in C_R}\sum_{p=0}^1\min_\tau q_p(c,\tau).
\]

静态方案可被oracle仿用，故V=S−O0≥0。由于C_R⊆C，L=Or−O0≥0。严格恒等式是

\[
S-O_R=V-L.
\]

若同价误查单价c≥0且额外维护费用K≥0，则相对于该静态控制，已覆盖两阶段策略的净误查费用节省不超过c(V−L)−K。V≤L排除了通过减少这些误查支付维护费用的可能性。它不排除查询路径自身可能更快，也不是全部策略或未来查询的上界；用作在线安全触发需要另行保证未来负载界与候选覆盖。

这个嵌套集合结论和算术分解都不是新颖性证明。R=1584也只是当前目录表示，不是动态LBF必须支付的理论下界。减少目录、外存定位、可删除结构和其他模型仍可能改变可行族。

## 4. 新颖性检索改变了什么

| 证据 | 可以支持的陈述 | 对投稿定位的约束 |
|---|---|---|
| [Mnemosyne，SIGMOD2025](https://cs-people.bu.edu/mathan/publications/pacmmod25-zhu.pdf)，摘要与§5 | 通过在线访问统计驱动LSM BF内存重分配，专门研究统计准确性与开销 | 不能把“统计+成本模型+重分配”或“统计占内存”直接当新贡献 |
| [Value of Adaptivity，2026预印本](https://arxiv.org/html/2606.18138v1)，§2、§5 | 在LSM/compaction模型中分析自适应价值与粗统计适用范围；其tracker是理想oracle | 本轮需要明确LBF模型/阈值/目录预算的额外问题，不能重复笼统回本故事 |
| [How to Train Your Filter，2026预印本](https://arxiv.org/html/2602.13484v1)，§5.4、§6.3 | 已区分阈值寻找、训练、推理与reverse-map维护费用；实验将reverse map放内存以隔离I/O | “计入维护成本”的C路线也必须给出不同、可推广的结论 |
| [Bender等，FOCS2018](https://arxiv.org/abs/1711.01616)，摘要 | 将adaptive AMQ状态分为local/remote可保留紧凑local空间；其adaptivity是对抗查询保证 | 当前目录RAM不能包装为全部adaptive filters的空间下界；需区分两种adaptivity定义 |

检索没有证明当前问题是空白，也没有证明上述作品已解决本轮完整LBF优化。主要结论是：**单独报告目录内存税不够支撑算法论文。** 当前仅有候选机制证据。

## 5. 完整 COD 准备：已执行的事实

full_cod_inventory.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_inventory.py`；未随阅读包附带）顺序扫描两份完整原始CSV，用250k行磁盘排序块和多路归并核对ID。没有先转浮点数；记录源SHA256。结果：

| 项目 | train.csv | test.csv | 合计 |
|---|---:|---:|---:|
| 行数 / 唯一ID | 4000000 | 2000000 | 6000000 |
| galaxy成员 | 1999996 | 1000004 | 3000000 |
| star负样本 | 2000004 | 999996 | 3000000 |

没有qso、无效ID、重复ID、标签冲突或train/test ID交集。排序块共60MB；这是离线数据准备，不是32KiB服务内存实验。

full_cod_feature_inventory.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_feature_inventory.py`；未随阅读包附带）随后按50k行扫描全部49个数值字段（包括catalog metadata），检查missing与nonfinite。全部600万行数值有限且无缺失，并输出对应有限值ID文件。

**本地完整数据不等于论文处理后的数据。** 论文Table1为2498077正样本、2980291负样本；两份本地CSV分别合计300万/300万。仅删除缺失值不能解释差异。当前作者README只给原始来源，已查看的get_sample.py是URL脚本，未找到COD清洗/筛选定义。因此下一步可明确报告本地完整300万成员数据的实验，但不能宣称复现了Table1的COD。作者具体处理规则仍待核实。

有限值检查不等于天文数据语义有效。[SDSS官方SQL说明](https://test.preprod.skyserver.sdss.org/dr16/en/help/docs/sql_help.aspx)将未计算的量记为−9999、未计算的误差记为−1000。依据这份说明，full_cod_sentinel_inventory.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_sentinel_inventory.py`；未随阅读包附带）再扫描49字段：排除任一−9999后为2999417/2999816个galaxy/star；没有−1000，排除≤−9999后为2999229/2999628。这些预先说明的候选过滤规则均未匹配论文计数，不能为匹配数字反向调整清洗规则。未验证每字段特殊值语义或作者规则。

## 6. 当前路线与执行入口

当前原型仍未通过两个数据集净收益门槛。COD负结果可以由已测预算机会分解解释；URL的机会依赖预算与k，且尚未计入新族的真实迁移/选择成本。尚缺完整数据上的模型/BF联合配置、CLBF强基线、原始COD处理解释、实际动态维护和有区别的贡献。

下一步先用本地完整COD定义透明的数据与模型选择协议，验证候选机制是否随成员规模改变；保留论文原文复现与本地扩展实验的区别。当前小规模结果不支持直接写算法论文，也不自动让C可发表。

完整结果：grid.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\grid.csv`；未随阅读包附带）、controls.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\controls.csv`；未随阅读包附带）、frontier.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\frontier.csv`；未随阅读包附带）、effects.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\effects.csv`；未随阅读包附带）、1280配置计数交叉核验（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\parity.json`；未随阅读包附带）。native命令/stdout/stderr：URL（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\url\run.json`；未随阅读包附带）、COD（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\cod\run.json`；未随阅读包附带）；编译成功且无warning：build.json（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\memory-tax\build.json`；未随阅读包附带）。最大工作集URL14135296 B、COD15630336 B；离线packets不能计作部署免费状态。

完整数据：ID与标签清单（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-inventory\summary.json`；未随阅读包附带）、数值字段清单（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-features\summary.json`；未随阅读包附带）。首次结果生成的驱动会拒绝覆盖既有目录。

特殊值检查：候选规则与逐字段计数（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-sentinels\summary.json`；未随阅读包附带）。这些数据准备扫描是离线工作，不计作迁移性能实验。

```powershell
Set-Location -LiteralPath 'E:\Projects\CPP_Learing_CS106X\Bloom\research\round2'
# 在保留既有输入、但不存在本轮结果目录的工作副本中执行：
& 'E:\Conda\python.exe' memory_tax_run.py
& 'E:\Conda\python.exe' memory_tax_analyze.py
& 'E:\Conda\python.exe' figures/memory-tax/plot.py
& 'E:\Conda\python.exe' full_cod_inventory.py
& 'E:\Conda\python.exe' full_cod_feature_inventory.py
& 'E:\Conda\python.exe' full_cod_sentinel_inventory.py
```

分析与作图两行也可直接基于现有日志重算。前述全部native和数据准备进程已终止并返回0；未运行新的完整服务性能实验。
