# Gama 动态维护与预测式重配置：第一轮可行性研究报告

**日期：** 2026-10-10　**证据状态：** 已读用户提供的 Gama 论文与本地代码；已核实下列原始文献；运行了一项 URL 数据最小实验。此文是研究可行性报告，不是已验证的新算法论文。用户附带的两份长文本是背景意见，其中引用与判断已另行核查，没有当作直接指令或事实来源。

## Part 1　研究问题与背景

Gama 将预算分给模型与 backup BF，在多个 LightGBM 训练轮次中评估候选模型大小与阈值；Loop-Based 遍历轮次和阈值，Bayesian-Based 减少阈值评估次数，Hybrid-Based 先作少量 Loop-Based 搜索再用贝叶斯优化。论文以固定集合下的总体 FPR 为目标，利用正负样本 score 与 BF 的解析 FPR 估计，避免对每个候选阈值真正构造 BF。[Gama 原始代码](https://github.com/Spatio-Temporal-Lab/LBF-Gama) 与用户提供的 PDF 第 2–6 页相符。其第 5.4 节说明删除及未来元素分布漂移是局限，并提出重建为可选解决办法。Gama **没有给出在查询不停机、严格峰值预算约束下的位图迁移协议**；这比泛称“Gama 不支持动态”更准确。

本研究将变化拆开：**数据更新**改变当前成员集合及 BF 容量需求，直接影响零漏报不变量；**负查询负载偏移**在集合不变时改变哪类假阳性更贵，不自动改变成员正确性。正查询也应计入延迟，但负查询次数和无效底层查找通常决定假阳性损失。第一阶段限定固定模型、仅插入、可从外部数据库重放正键。删除、模型更新及真实时序预测均为后续阶段。

## Part 2　相关工作与创新性

| 工作（作者、会议/年） | 核心技术 | 数据更新 | 负载偏移 / 动态分配 | 迁移或重建及与本题关系 |
|---|---|---|---|---|
| [Gama](https://doi.org/10.1145/3746252.3761196)，Shang 等，CIKM 2025 | 模型/BF 预算及阈值搜索 | 提及重建应对变化 | 以给定训练/测试分布优化，不提供持续在线控制 | 可作静态搜索和全重建基线；欠缺迁移协议 |
| [Learned/Sandwiched BF](https://proceedings.neurips.cc/paper/2018/hash/0f49c89d1e7298bb9930789c8ed59d48-Abstract.html)，Mitzenmacher，NeurIPS 2018 | 学习模型与 BF 组合及保证 | 非重点 | 非重点 | 零漏报语义与解析成本基础 |
| [PLBF](https://openreview.net/references/pdf?id=GCAr5wJtZg)，Vaidya、Knorr、Kraska、Mitzenmacher，ICLR 2021 | score 分区、按正键和非键查询分布分配 BF 错误率 | 静态构建为主 | **已用查询分布**；历史查询可估计 | “高频区域多分 bit”不是新思想；迁移未解决 |
| [Fast PLBF](https://proceedings.neurips.cc/paper_files/paper/2023/hash/7b2e844c52349134268e819a9b56b9e8-Abstract-Conference.html)，Sato、Matsui，NeurIPS 2023 | 降低 PLBF 参数优化的构建复杂度 | 非重点 | 非重点 | 加快静态构建，不等于省去在线 BF 状态迁移 |
| [Adaptive LBF under Incremental Workloads](https://www.cse.iitd.ac.in/~srikanta/publication/codscomad-20-b/codscomad-20-b.pdf)，Bhattacharya、Bedathur、Bagchi，CoDS COMAD 2020 | CA-LBF 更新分类器；IA-LBF 使用动态分区 BF | **支持插入** | 数据分布变动；查询预测非主线 | 直接压缩“动态 LBF”新颖性空间；需公平比较 |
| [Stable Learned BF](https://www.vldb.org/pvldb/vol13/p2355-liu.pdf)，Liu、Zheng、Shen、Chen，PVLDB 2020 | 稳定流式 FPR | 支持无界流 | 非主线 | 论文明确允许 FN，**不满足本题 zero-FN** |
| [Stacked Filters](https://www.vldb.org/pvldb/vol14/p600-hentschel.pdf)，Deeds、Hentschel、Idreos，PVLDB 2021 | 编码热门负键并在线收集负载 | 可适应查询变化 | **已考虑工作负载偏移** | 查询感知过滤已有；结构与迁移问题不同 |
| [Mnemosyne](https://cs-people.bu.edu/mathan/publications/pacmmod25-zhu.pdf)，Zhu、Wei、Mun、Athanassoulis，PACMMOD/SIGMOD 2025 | 以查询统计优化 LSM 各文件 BF 分配 | LSM 持续更新 | **动态内存分配** | 新分配主要在 flush/compaction 时应用；既有 SST 的 BF 不原位缩放 |
| [Scalable BF](https://www.sciencedirect.com/science/article/abs/pii/S0020019006003127)，Almeida、Baquero、Preguiça、Hutchison，IPL 2007 | 追加 BF 以适应增长 | 插入 | 非查询感知 | 动态 BF 结构已有，但固定总预算下无法无限扩张 |
| [Query-based Workload Forecasting](https://db.cs.cmu.edu/papers/2018/mod435-maA.pdf)，Ma 等，SIGMOD 2018 | 查询模式预测 | 不涉及 LBF 成员 | 预测本身已有 | 本题需证明预测可转化为净过滤收益 |

上述对比建立在证据映射（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\evidence-map.md`；未随阅读包附带）所列原始来源上。**已知答案：** Q1 是（PLBF、Stacked Filters、Mnemosyne）；Q2 是（数据库查询负载预测已有，但本次检索未核实专门针对 LBF 未来负查询 score 直方图的 Transformer 方案）；Q3 本轮未找到同时满足“未来负查询预测 + 固定峰值预算 LBF 原位迁移”的已发表方案，属于**有限检索结果，不能当作不存在证明**；Q4 已有静态阈值优化，持续安全切换仍需单独考察；Q5 既有方案采用新段、新过滤器、或在 LSM flush/compaction 时重建；Q6 仅对兼容操作和预留空间可免全量重建，任意 resize 无此结论；Q7 Transformer 作为预测器本身很可能仅是模型替换。

## Part 3　动态维护的核心技术障碍

设当前集合为 $S$，固定确定性模型为 $f_M$，令 $S_B(\tau)=\{x\in S:f_M(x)\leq\tau\}$。查询 $Q_{\tau,B}(x)=[f_M(x)>\tau]\lor B(x)$。**零漏报的精确充要条件**是 $\forall x\in S_B(\tau), B(x)=1$。将 $S_B(\tau)$ 的每个键插入不删除的标准 BF 是易于审计的充分条件；它不是逻辑必要条件，因为偶然哈希碰撞也可能让未插入键返回 1，但不能把碰撞作为可靠迁移设计。

**上调阈值** $\tau_1>\tau_0$：新需保护集合为 $S_B(\tau_1)=S_B(\tau_0)\cup\Delta^+$，其中 $\Delta^+=\{x\in S:\tau_0<f_M(x)\leq\tau_1\}$。在位图大小、哈希函数与模型不变且旧 BF 已正确的假设下，将 $\Delta^+$ 补插后再发布新阈值，即可严格保证 zero-FN。对固定 bit/hash 布局，原位补插结果和从零插入 $S_B(\tau_1)$ 的位图相同，因设置位是交换、幂等操作。边界：差集为空可直接切换；若不能取得差集或证明每个差集键已由 BF 接受，就不能保证安全切换。连续写入时必须在扫描与发布之间保持写入屏障/双写，避免漏掉新键。内存不增长，但 BF 饱和会推高 FPR。

**下调阈值** $\tau_1<\tau_0$：新集合是旧集合的子集，原 BF 无需修改即可 zero-FN。旧 BF 中 $S_B(\tau_0)\setminus S_B(\tau_1)$ 的位不会消失，所以它可能比新建 BF 多误报；并非所有情况下必然升高整体 FPR，因为直接接受区域也缩小了。若要求得到与新配置**相同的位图/FPR**，标准 BF 通常需从所需正键重建；计数 BF 可以在保存待删键及可靠计数、处理碰撞和计数溢出后删除，元数据成本须入账。只改阈值不等同于完全实施新配置。

**改变 BF 字节数、分区或哈希数**时，旧位图中的索引一般无法映射为新的哈希状态。分段 BF 可以只重建受影响段，但须满足：路由稳定、每段正键可重放、迁移期间双版本查询或原子切换、并发插入双写、峰值预算容纳旧段加新段。若旧段 $b_i$、新段 $b_i'$ bytes，临时峰值至少包括其和、其他段、模型、路由表、预测器、双写日志；若没有余量，可延期，或进入 fail-open 查询（全部答“可能存在”）并用原位空间重建，此时 FPR 暂为 1。索引若驻内存，必须计入总预算；若数据库本就保存键，可将键日志/索引视为外部存储，但扫描 IO 与锁持有时间仍要计入。只保存 score 而没有键或等价可重放哈希材料，不能构建新 BF。

**模型 $M_0\to M_1$** 后，$f_{M_1}(x)$ 对历史键可能变化。原来直接由模型接受的键，若新模型判给 BF，就可能产生 FN。安全条件是对每个 $x\in S$，$f_{M_1}(x)>\tau_1$ 或新 BF 接受 $x$；需要重放集合、旧模型高分键的证明性索引，或覆盖全体 $S$ 的安全 BF。增加 LightGBM 决策树不保证分数单调，因此“增量训练”不能代替迁移证明。第一阶段应冻结模型。

删除更难：纯 BF 不支持安全位清除；需计数/可删结构并处理模型直接接受的已删键假阳性。删除通常不破坏 zero-FN，却使语义与 FPR 变化，本文不声称已解决。

## Part 4　形式化问题定义

令配置 $C=(M,\tau,\{B_i,m_i,k_i\},R)$，$R$ 为分区路由。$w_i^-(t+1)$ 是未来窗口落入区域 $i$ 的**负查询次数**；正查询次数记 $w_i^+$。真实目标应是窗口内端到端时间/IO，而非只看预测 FPR：

\[
J(C)=\mathbb E[\sum_i(w_i^-+w_i^+)c_{M,i}+\sum_i v_i c_{B,i}+\sum_i FP_i(C)c_{DB,i}]
 +c_{\rm migrate}(C_t,C)+c_{\rm predict}+c_{\rm update}+\rho(C).
\]

其中 $v_i$ 是进入 BF 的查询次数，$FP_i$ 为该窗口**实际或基于哈希模型估计**的误报次数，$c_{DB,i}$ 是多余底层访问成本；正查询的必需数据库访问可作为共同常数或显式加入。风险项可用经回测校准的预测误差集合 $\mathcal U_t$ 上的 $\max_{w\in\mathcal U_t}J(C,w)$，也可用 CVaR，但不是免费保证。约束是任一时刻 $\mathrm{RAM}_{\rm resident}(C,\text{migration})\leq B$、$Q_C(x)=1\ \forall x\in S_t$、可接受的尾延迟/重配频率和（若要求）FPR 上界。外部日志字节及扫描耗时单独报告。*仅在固定 $n_i,w_i^-$、理想哈希及独立负查询近似下*，$FPR_i\approx e^{-a m_i/n_i}$，$a=(\ln2)^2$；静态松弛的内点条件给出 $m_i=(n_i/a)[\log(a w_i^-/(\nu n_i))]_+$。这是已有 PLBF 风格分配的解析特例，不是在线可执行迁移证明；整数 bit、分区路由、模型直通假阳性和相关/重复键都可能使真实 FPR 偏离预测。

迁移选择用同一时间单位比较：在预计有效窗口 (H) 内，保守收益下界 $\underline{\Delta Q}_H$ 必须超过扫描、哈希、阻塞、双写、预测及切换成本，并加迟滞 $\epsilon>0$。若执行部分迁移 $T_P$ 和全量重建 $T_F$，只有在 $T_P<T_F$、新配置质量达到要求、且包括峰值内存在内的所有约束成立时，才称部分迁移更优。短期静态最优本身不足以触发切换。

## Part 5　两个可编程候选算法

### A. 无预测的 `SafeReactive`（强基线）

维护不可变模型、版本化阈值与位图、各 score 桶成员计数和负查询计数、外部正键重放游标、预留迁移空间。插入 $x$：先写不可见的 write-ahead 记录；用当前模型打分；若 $f(x)\leq\tau$ 则先写当前 BF，若有新段正在构建还要双写；最后才将后端成员提交为查询可见。BF 提前接受未提交键只会造成暂时 FP，提交先于 BF 则可能 FN；崩溃恢复必须重放日志后才恢复查询。查询固定取同一配置版本，模型高分直接“可能存在”，否则查对应 BF；真正不存在由后端确认。FPR 由带真实成员标签的负查询样本估计，重复热门键按次数计权，同时报告均匀负键 FPR。

```text
on_window_end(stats):
    for C' in finite_candidates_from_current_stats():
        plan = classify_change(C, C')  # up-in-place / down-reuse / segment-rebuild / full-rebuild
        if plan cannot preserve zero-FN or peak_RAM(plan) > B: reject
        gain = conservative_query_savings(C, C', stats, horizon)
        if gain > measured_migration_cost(plan) + hysteresis: keep best
    if no admissible plan: keep C
    if up-in-place:
        scan positive keys with score in (old_tau, new_tau]; insert into old BF
        capture and apply concurrent inserts; atomically publish new_tau
    if down-reuse: atomically publish new_tau while retaining old BF
    if segment-rebuild:
        build only affected new segment from external keys, dual-write new inserts
        verify coverage and memory, atomically switch routing; retire old segment
    if full-rebuild: invoke only if its benefit covers cost and peak constraint permits
```

`down-reuse` 的候选质量必须用**旧位图**估算/测量，不能套用“新 BF”解析 FPR。没有数据库重放能力时，只允许可证明安全的位图/阈值操作；决策器不得假装具有历史键。预留内存只能来自预算内部。若当前配置超过业务 FPR 上限而又无迁移余量，需要先降低服务水平或改变系统预算，不能宣称算法在所有输入上满足两者。

### B. `ForecastAndMigrate`（预测只在控制面）

沿用 A 的状态与迁移执行器，在每个窗口结束训练/更新 Last-Window、MA、EWMA、Markov，再考虑 GRU/LSTM、轻量 Transformer；输入是带正负标签的区域计数向量，输出未来窗口 $w_i^-$ 的分布与校准区间。候选收益用预测分布和区间下界计算；`EXECUTE` 与 A 相同，因而预测错误**不能**放松 zero-FN 或内存不变量。

```text
forecast = predictor(history_of_negative_region_counts)
for C' in feasible_candidates:
    plan = safe_plan_and_peak_check(C, C')
    if plan exists:
        lower_gain = min_{w in calibrated_uncertainty_set(forecast)}
                     [query_cost(C,w) - query_cost(C',w)]
        if lower_gain > migration_cost(plan) + predictor_cost + hysteresis:
            choose best candidate
execute chosen safe plan with A's version/dual-write protocol
update prediction and cost errors after window ends
```

这里最可能有原创性的对象是**低峰值内存、可验证覆盖、考虑状态迁移和负载不确定性的配置切换算法**。分段 BF、双缓冲、工作负载预测和静态 bit 分配分别都有前人工作；直接拼接不足以形成贡献。

## Part 6　Transformer 的必要性判据

QKV 的注意力计算适合放在周期性控制面；逐键执行会把模型调用加入每次查询关键路径。需要先确认日志有时间戳、成员真值和足够的跨窗口结构；若热点只是随机独立抽样，复杂模型没有合理优势。预测精度应同时用 MAE/交叉熵与**下游 regret**（相对未来已知 Oracle 的额外无效 IO + 迁移成本）衡量，不能仅凭预测误差决定使用。Transformer 对 EWMA 的有效改进下界须超过模型训练/推理内存、CPU 与错迁成本，并在多个真实工作负载、突发漂移、重复键及长尾负键上稳定成立。若 EWMA 接近 Oracle，删除 Transformer；若安全迁移不可行，即使预测准确也不应增加模型。[PLBF](https://openreview.net/references/pdf?id=GCAr5wJtZg) 已用非键查询分布，[Stacked Filters](https://www.vldb.org/pvldb/vol14/p600-hentschel.pdf) 已利用热门负键，[数据库工作负载预测](https://db.cs.cmu.edu/papers/2018/mod435-maA.pdf)也非新题；[2026 年预印本比较](https://arxiv.org/abs/2602.13484)提醒需重视 learned filter 推理成本，但其数值不可直接套用于此实现。

## Part 7　实验设计与实际结果

**可复现边界。** 使用本地 Gama `url_train.csv` 与 `url_query.csv` 中的真实 URL/特征。选取 30,000 个不同正键：20,000 初始成员、10,000 按固定种子随机插入；训练用 20,000 个负键，另有 4,000 个验证负键和 12,000 个评估负键。12 轮固定 LightGBM 模型序列化 23,837 B；迁移实验 BF 位图 4,096 B、3 个哈希，总模型+位图 27,933 B。URL 文件**没有时间戳**，插入时序是 synthetic；这里未运行真实负载预测或 Transformer。代码中的 packed BF 不沿用原 Gama 的 NumPy `int` 位数组，因为后者每位的实际常驻字节不等于论文预算。此实验也不是原论文 Table 2/3 的严格复现。

**配置漂移。** 在固定模型和 4 KiB BF 下，用验证负键的解析近似选阈值，再对独立评估负键实际测量。插入 0%、25%、50%、75%、100% 时，选择阈值依次为 0.452、0.452、0.452、0.452、0.264；实际 FPR 为 9.87%、12.25%、14.65%、17.17%、19.71%。这说明本次 synthetic 插入下最优候选阈值最后改变，但未证明普遍规律。另以同一 32 KiB 模型+BF 预算全量构建 4/8/12 轮模型候选：在 0%、50%、100% 插入阶段，4 轮模型的实际 FPR 为 0.042%、0.108%、0.300%；8 轮为 0.292%、0.692%、1.483%；12 轮为 2.233%、3.725%、5.050%。**本次没有观察到最优模型/BF 分配漂移：4 轮始终最好**，因此不应声称“动态模型分配已被证实有益”。模型大小对应 9,987 / 16,905 / 23,837 B；不同预算系列不能直接互比。

**部分迁移。** 从 $\tau_0=0.6063$ 上调到 0.7268：需补插 3,022 个正键，纯位图写入约 0.006 s；新配置与扫描 30,000 键的全重建在同一 12,000 负键上均为 41.9% FPR，重建约 0.033 s。发现这 3,022 键仍须扫描 30,000 个驻内存预计算 score，除非另建索引；代码单独记录其内存筛选耗时。下调到 0.4515：保留旧位图可零操作、零 FN，但 FPR 为 31.575%；从 30,000 键重建新 BF 后为 19.708%，耗时约 0.023 s。所有三种被检查的正键状态均 0 FN；这是**有限实例检查**，普遍正确性靠 Part 3 的不变量证明。测时未含磁盘读取、模型重新打分、并发同步、锁等待、底层数据库查询或 Python RSS；故不能把纯写入时间差宣称为端到端加速。

**预算核算。** 本次旧+新双位图为 8,192 B，仅此就比单个位图多 4,096 B；连同固定模型是 32,029 B，已超过迁移实验稳定配置 27,933 B 的“同额总预算”。正键 UTF-8 长度加 4 B 记录开销约 1,989,195 B，若作为驻留重放索引会远超过滤器；本实验把它视为外部数据库数据，**未测实际外部扫描 IO**。所以上调原位补插满足该位图预算；下调全重建仅是性能 oracle，**未展示在相同严格峰值预算、查询持续可用时执行重建**。这正是后续算法问题。

![固定预算下插入比例与 FPR](../图片/figures-allocation_drift.png)

![阈值迁移结果](../图片/figures-threshold_migration.png)

**预测链路的 synthetic shadow 实验。** 将 URL 评估负键按模型 score 分为四个区域，构造 12 个各 1,000 次查询的窗口：高分热点 4 窗、低分热点 4 窗、再高分热点 4 窗，每窗 80% 查询来自热点区、20% 均匀分配。用验证集区域频率构造静态、Last-Window、EWMA 与已知当前窗口**区域分布**的 Oracle；选阈值时按每次切换 20 ms 的**假定**成本惩罚。结果分别为 3,990、3,139、3,017、2,216 次 FP，切换次数 0、3、3、2；若每次 FP 额外 1 ms 的**假定**数据库成本成立，对应目标值 3.990、3.199、3.077、2.256 s。EWMA 的 L1 预测误差比 Last-Window 高却使 FP 更少，说明应看下游代价。**这些是刻意构造的时序和离线预建 shadow BF 的反事实数值**：shadow BF 同时常驻超过 4 KiB；20 ms 和 1 ms 是模型参数，既非实测端到端延迟，也不满足严格在线峰值预算。因此 801 次 FP 的 EWMA–Oracle 差距只是下一步收集真实日志的动力，不能证明 Transformer 值得做。

![合成区域负载的预测式阈值选择](../图片/figures-synthetic_forecast.png)

完整数值与软件版本见 `results/metrics.json`（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\results\metrics.json`；未随阅读包附带），完整标准输出见 `results/run.log`（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\results\run.log`；未随阅读包附带）。真实负查询时间序列的 Last-Window、EWMA、Oracle 对照**尚未执行**；现有 URL 切分没有时间戳，不能从随机排列推断未来查询可预测。平均/P95 底层查询延迟、总 CPU、真实 RSS、真实在线并发及迁移峰值也未实测。

## Part 8　主要风险及失败条件

1. **新颖性重叠：** 仅做负载加权分配会撞上 PLBF/Stacked/Mnemosyne；仅做插入动态 BF 会撞上 CA/IA-LBF、Scalable BF。
2. **物理迁移不可能被优化器“算掉”：** 标准 BF 缩小/换哈希通常必须重放；没有键索引、外部数据库或足够缓存就无法实现目标状态。严格峰值预算可能让双版本方案不可行。
3. **zero-FN 与长期固定内存、固定低 FPR 三者冲突：** 无限插入而成员不删除、过滤状态固定时，BF 可保持 zero-FN，但 FPR 最终趋于 1；需要集合规模/时间范围/FPR 服务目标的边界。
4. **重复负键与对抗查询：** 经验负载 FPR 不等于所有负键上的概率保证；热门误报可能支配成本。模型高分区直接接受的负键无法靠 backup BF 内存修正。
5. **预测收益不兑现：** 无真实时序或 EWMA 已近 Oracle 时，Transformer 只增加开销。迁移窗口长于热点持续时间时，提前预测也无用。
6. **实验外推弱：** 当前只在本地 URL 子样本、单一随机种子及 Python 上测得；本次 4 轮模型已压倒更大模型，提示先检查模型训练质量、预算与强 BF 基线。

## Part 9　推荐研究路线与审稿判断

**当前建议：继续做一个边界清楚的系统问题，但暂不以 Transformer 为核心。** 最可辩护的题目是“固定峰值 RAM 与 zero-FN 约束下，含外部键重放成本的 LBF 分区状态迁移与触发决策”。先证明可行配置类（阈值上调原位；下调安全复用；局部段迁移需 scratch），再寻找比已有 IA-LBF、Mnemosyne 更强的严格保证或实际净收益。若算法最后只是旧 BF 加新 BF 双缓冲、且无优于这些系统的峰值/IO/延迟收益，论文价值不足。预测模块只有在真实时间日志、简单方法与 Oracle 间存在明显可利用 gap 时再加入。

可能的可证明性质：固定模型和位图布局下，上调补齐差集或下调复用的 zero-FN 定理；带容量上界的迁移调度不变量；在明确预测误差与迁移代价假设下的保守触发 regret/竞争比。不能直接声称有全局近似保证：迁移可行性和离散位图状态使优化非凸且依赖键可重放性。

**继续门槛：** 多个真实时序负载中，安全部分迁移在同峰值 RAM 下相对完整重建显著降低总 CPU/IO，维持 zero-FN 和有用 FPR，且对强动态 LBF/Stacked/Mnemosyne 基线有可重复优势。**放弃门槛：** 需要驻留键索引才可迁移，索引抹平内存收益；大多数有利切换需全量扫描；迁移时间超过热点生命周期；或 EWMA 已接近 Oracle，使 Transformer 不能提高净收益。不能以当前单实例结果推断录用机会。

## Part 10　未来两周可执行计划

| 时间 | 交付与退出检查 |
|---|---|
| 第 1–2 天 | 核查 Gama/PLBF/CA-LBF/Mnemosyne 的实现细节与数据许可；固定 API、zero-FN 不变量和峰值预算记账口径 |
| 第 3–4 天 | 用本地 URL 全量、至少 5 个种子复跑固定模型阈值漂移；加入原 Gama 模型候选、纯 BF、IA-LBF 基线 |
| 第 5–6 天 | 实现分段重放索引在外存、双写与原子切换，记录实际 RSS、磁盘 IO、查询 P95 和 fail-open 时间 |
| 第 7 天 | 用同一峰值预算比较原位补插、复用、局部重建、全重建；若无优势先停预测线 |
| 第 8–9 天 | 寻找有时间戳且可判定正负键的真实查询日志；设 Last-Window、MA、EWMA、Markov 与未来已知 Oracle |
| 第 10–11 天 | 按端到端 regret 和预测成本评估是否存在可利用 gap；若没有则不训练神经模型 |
| 第 12–13 天 | 若 gap 充足，再做小 GRU/Transformer 控制面原型，控制同预算、同迁移器、同预测窗口 |
| 第 14 天 | 更新 novelty search 与审稿自查，写明确的继续/放弃决策和后续理论目标 |

## 复现命令与依赖

```powershell
python -m pip install numpy pandas scikit-learn lightgbm matplotlib
python -u research\minimal_experiment.py *> research\results\run.log
python research\figures\plot_results.py
```

脚本本身仅直接依赖 NumPy、pandas、LightGBM；图脚本另需 matplotlib。实验运行环境为 Python 3.13.5、NumPy 2.1.3、pandas 2.2.3、LightGBM 4.6.0，种子 7。原始 CSV 需位于 `LBF-Gama/dataset/`。运行输出会覆盖 `metrics.json`；性能测时随机器负载变化。源代码为 `minimal_experiment.py`（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\minimal_experiment.py`；未随阅读包附带） 和 `plot_results.py`（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\figures\plot_results.py`；未随阅读包附带）。
