# 完整本地 COD：模型/BF 配比与插入后端点验证

2026-10-11。已执行数据准备、初始训练、验证集配置选择和独立测试集原生位图评估。论文目标仍 active；本轮没有测在线迁移净收益。

## 1. 范围与公平性

- 本地两份原始 CSV 共 600 万唯一 ID：300 万 galaxy 成员、300 万 star 非成员。论文 COD 样本数不同，本实验是透明定义的完整本地扩展，不能写成作者预处理的复现。
- 使用全部 49 数值字段，保留有限的 -9999 特殊值；插入顺序由固定 hash 划成两批，属于合成顺序。初始成员 1,999,996，随后增加 500,177 和 499,827。
- 初始训练仅用初始成员和 1,600,468 个训练负样本；399,536 个验证负样本用于选择，999,996 个测试负样本从未用于训练或配置选择。仅训练一次模型，之后不重新训练。
- 候选模型为 0/1/2/4/8/12/24/48 棵树，每棵导出载荷 700 B。16 个 hash 区域，预算包括模型载荷、BF 位图及公共 2,048 B 状态预留。只搜索最大填充的等大位图，不宣称全局最优。
- 使用 Eq.3 风格解析 FPR 在原生整数分数的全部边界选阈值和 k∈[1,16]；冻结 84 个不同描述符后，才构建原生 BF 并读取测试负样本特征。

## 2. 实测结果：无额外目录预留

| 状态预算 KiB | 初始模型树数 | 初始测试 FPR | 300 万成员继续 Hold | 固定模型重选阈值/k | 联合重选模型/阈值/k | 最终模型树数 |
|---:|---:|---:|---:|---:|---:|---:|
| 64 | 8 | 6.6758% | 11.8286% | 9.6371% | 9.5122% | 24 |
| 128 | 48 | 3.0748% | 6.4386% | 4.5251% | 4.5251% | 48 |
| 256 | 48 | 1.0489% | 3.1435% | 1.8164% | 1.8164% | 48 |
| 320 | 48 | 0.6971% | 2.6920% | 1.2809% | 1.2809% | 48 |
| 1024 | 48 | 0.0261% | 0.2938% | 0.0902% | 0.0902% | 48 |

![独立测试集 FPR](../图片/full-cod-full-cod.png)

### 收益分解

| 预算 KiB | 相对 Hold 少的误查 | 固定模型贡献 | 再改模型的增量 |
|---:|---:|---:|---:|
| 64 | 23,164 | 21,915 | 1,249 |
| 128 | 19,135 | 19,135 | 0 |
| 256 | 13,271 | 13,271 | 0 |
| 320 | 14,111 | 14,111 | 0 |
| 1024 | 2,036 | 2,036 | 0 |

解释：128 KiB 及以上始终选 48 棵树；在这个有限候选池里，联合优化收益完全由固定模型的阈值/k 调整获得。64 KiB 模型树数随快照变化，但初始 FPR 约 6.7%，且最终改变模型的额外收益较小。不能据此声称低 FPR 配置中频繁发生模型/BF 配比变化。

所有同模型目标阈值都低于初始阈值；320/1024 KiB 的最终 k 还改变了。实测目标是干净重建的 BF。Hold 则在原布局、原阈值下插入全部新增成员，与单调插入得到的旧位图一致。阈值下调后复用旧 BF 的多余位无法删除；本轮收益不能直接归于已实现的上调补插执行器。

额外 1,584 B 预留的完整结果见 method-results.csv。它仅是旧 66 项原型目录的空间敏感性，不代表完整 COD 的可部署目录：48 树最终精确 CDF 有 1,037,884 个边界，不能塞入该空间。

## 3. 费用与内存边界

- 初始训练 13.469 s wall / 27.516 s CPU，Python 峰值工作集 3,438,166,016 B；属于离线训练，不在服务预算内。
- 原生准备 8 个前缀分数缓存，扫描当前成员及验证原始特征约 1.36 GB；各输入的 CPU/读取/写入量见 score-run.json。缓存只用于离线端点评估，不能当成免费历史访问。
- 全部 240 个解析配置搜索为 4.532 s wall / 4.500 s CPU，Python 峰值工作集 381,583,360 B。没有证明廉价在线选择器；与旧 0.95 s 选择费用的范围不同，不能算速度提升。
- 84 个原生端点全部成员 FN=0，最大请求状态 1,048,576 B；原生进程峰值工作集 9,510,912 B。进程设 32 MiB 配额。公共预留不是完整 49 特征在线服务的内存证明，流缓冲、Key 临时对象、模型容器及运行库与状态预算分开。
- endpoint 中 wall/CPU 包含缓存成员构建、成员检查、验证与原始测试评分，且是顺序热文件实验；不是迁移延迟、物理冷 IO 或纯查询 CPU，禁止拿它直接计算在线净收益。
- 分数抽样最大原始 margin 误差 3.39e-13；解析估计与真实验证 FPR 的最大绝对差 0.00138927，与测试最大差 0.0012518。解析最小值不是精确位图最小值或总体 FPR 保证。

## 4. 数学结论与回本门槛

模型分数 f(x) 固定、阈值 τ 时，令 p(τ)=|{x∈S:f(x)≤τ}|，q(τ)=|{x∈V:f(x)≤τ}|，BF 有 m bits；选择目标为 F̂(τ,k)=1−q/|V|+(q/|V|)(1−exp(−kp/m))^k。它假设均匀 hash，实际区域占用与确定性碰撞由原生测量检验。

对 p>0，令 z=kp/m。log BF=(m/p)z log(1−e⁻ᶻ)；其唯一连续最小值在 z=ln2，故整数 k 的最小值在裁剪至 [1,16] 的 floor/ceil((m/p)ln2) 中。p=0 时 BF=0，选择 k=1。阈值仅在成员或验证分数处改变计数，全部边界足以穷举该解析目标。实现另在每个配置的最优点及最多 256 个分散边界枚举全部 16 个 k 检查；不是一种新算法贡献。

最小值的导数证明：令 t=e⁻ᶻ，导数符号等于 φ(t)=(1−t)ln(1−t)−t ln t。φ 在 0、1/2、1 的极限/值均为 0，φ″(t)=(2t−1)/(t(1−t))；因此在 (0,1/2) 严格凹且正，在 (1/2,1) 严格凸且负。故 z<ln2 时目标严格下降，z>ln2 时严格上升。

Zero-FN：所有 f(x)≤τ 的成员先插入同布局 BF，并逐一检查；其余成员由模型接受。因此每个已构建端点返回 positive。该证明不覆盖并发迁移中间态。

同模型同 k 同布局，仅上调 τ 时，可在发布新 τ 前补插分数带内成员；位图 OR 与全量重建相同。下调 τ 后旧位图含目标位图，保证 Zero-FN 但 FPR 可能更高；若改变 k、位图长度或模型，不能仅用该分数带论证迁移。

进一步，固定旧位图 B 时，接受集合 A(τ,B)={x:f(x)>τ}∪{x:BF_B(x)=1}。τnew<τold 蕴含 A(τold,B)⊆A(τnew,B)：直接下调而复用旧 BF 的误查数至少等于 Hold。又有 Bclean⊆Bold，所以 A(τnew,Bclean)⊆A(τnew,Bold)。这是逐 key 的确定性包含关系，不依赖 BF 解析近似。256 KiB 的同模型/k/布局情形满足该前提，故观测到的 FPR 改善必须依赖清理/重建，而不能由零回放阈值更新取得。它不排除 BF 查询 CPU 变化带来的其他收益。

在同一快照负查询分布下，若重复 H 个负查询、实测端点 FPR 差 Δf>0，忽略迁移期退化时毛收益为 HΔf·c。完整 CPU 条件应为 HΔf·c > K统计+K选择+K迁移+H·d负+(H正)·d正+K退化，其中 d 是新旧过滤查询 CPU 差。分子未测全前，不提供完整 c* 数字；等待时间和 CPU 分账。分布变化下 Δf 不可直接外推。

256 KiB 最终快照每 999,996 次负查询少 13,271 次误查；假设每次误查 CPU 费用 c=10/100/1,000 μs，允许支付的全部增量 CPU 上限分别只有 0.13271/1.3271/13.271 s。这是有利端点信息下的毛费用余量，不是已实现净收益；慢后端等待时长不能代入 CPU 费用。

## 5. 对论文路线的判断与下一步

本轮使一个原本不充分的动机变得具体：在百万级成员、初始低 FPR 配置中，固定模型的阈值下调确实有明显端点收益。但它没有证明需要改变模型大小，也没有证明严格峰值 RAM 下能以低费用取得该收益。

下一步锁定 256 KiB 的同模型、同 k 下调对照，先完整测量原始特征重评分的单遍 Full、可复用旧 BF 的 Hold/decrease 与既有分区重建，计入初始索引维护及查询退化。先算有利信息下的回本余量，再决定是否研发选择器；不增加新的审计架构或放大热 SQLite 重复。保留 320 KiB 作为改变 k 的边界案例，不混称分数带局部迁移。

投稿还缺第二个完整数据集、CLBF 与现代可更新结构的适用基线、真实合理后端的端到端成本、机制原创性及稿件。计数 BF/cuckoo 替换已有先例，不能凭此次阈值下降结果直接定创新题目。

## 6. 代码、记录与复现

协议：plan/full-cod-protocol.md（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\plan\full-cod-protocol.md`；未随阅读包附带）。源数据权威：完整 ID 扫描（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-inventory\summary.json`；未随阅读包附带）。

执行顺序：full_cod_prepare.py → full_cod_train.py → full_cod_score_run.py → full_cod_select.py → full_cod_evaluate.py → full_cod_analyze.py。工作目录为本文件所在目录，Python 为 E:\Conda\python.exe；运行驱动会拒绝覆盖既有结果。

源码：准备（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_prepare.py`；未随阅读包附带）、训练（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_train.py`；未随阅读包附带）、原生实现（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_native.cpp`；未随阅读包附带）、构建与分数核验（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_score_run.py`；未随阅读包附带）、选择（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_select.py`；未随阅读包附带）、评估（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_evaluate.py`；未随阅读包附带）、汇总（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\full_cod_analyze.py`；未随阅读包附带）。

日志与数据：训练（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\train.json`；未随阅读包附带）、构建（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\build.json`；未随阅读包附带）、分数准备（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\score-run.json`；未随阅读包附带）、选择费用（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\selection-profile.json`；未随阅读包附带）、冻结描述符（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\targets.txt`；未随阅读包附带）、原生逐例日志（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\endpoint.jsonl`；未随阅读包附带）、运行终态（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\endpoint-run.json`；未随阅读包附带）、全方法表（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\method-results.csv`；未随阅读包附带）、差值表（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\comparison.csv`；未随阅读包附带）、校验汇总（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\full-cod-joint\summary.json`；未随阅读包附带）。
