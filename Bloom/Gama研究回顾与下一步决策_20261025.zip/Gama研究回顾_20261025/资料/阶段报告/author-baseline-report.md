# 作者 IA-LBF/DPBF 动态索引复现

已补上一个真实的动态 LBF 索引基线：使用 [作者公开代码](https://github.com/arindambhattacharya/LBF/tree/c0343896e9b933c9dad6bd776ec2e36d0b0ea168/dpbf_classifier/src_bloom_classifier_with_dpbf)，保留 **puBFMap 与 CPBPT 两个结构**，固定 commit，原 checkout 无修改。完整参数网格 **288 行**，验证集选中配置和作者默认配置另做 **90 次重复**。全部已测 FN 为 0。

## 1. 实现与必要修复

port_author_dpbf.py 生成可审计派生源码：修复 root 替换后的查询游标、归并及临时链表释放、map/BF/sieve 销毁、饱和位图计数转换，并用显式 64 位算术保持 Linux unsigned long 的原语义。另发现集中前缀样例的真实 FN：为压缩内部 root 补齐上层时未逐层更新路径索引；已保存失败源码/二进制/log，修复为每步 index/=2。修复后 **50 个试验、363,000 个已有成员检查**和全部作者分配归零通过。未将该实现缺陷当成算法性能劣势。

包装器保持相同原生冻结分类器、阈值、URL key 与更新集合，用同一个 64 位 key hash 作为 DPBF ID。它替代原作者依赖 Python 进程 hash 的 feature-byte ID，原 GBDT 与作者实验的分类器也不同；这是**作者动态索引机制的修复复现**，不是原论文整套数据/模型结果的逐值复现。

深度 4/8/12/30、unit bits 256/1024/4096、k=3/7、设计 p=.01/.1，共 48 个组合/场景。分类器和阈值固定以比较索引；没有联合优化 DPBF 的模型/阈值。64 位稀疏 namespace 与这些深度不满足原 preprint 最细分区容量前提。原近似人口计数和 fractional merge 规则仍保留，**不能声称严格恒定 FPR 上界**；FPR 全部实测。

## 2. 内存统计重新计费

逐次追踪作者 malloc 与 std::map 的 new/delete，计入 map 对象/节点、每个最细 BF 的对象与位图、压缩树的对象/BF/位图、参数及瞬态完整叶复制/链表。加上模型容量、实际包装器和测量控制元数据。payload 是全部追踪的请求字节；instrumented 还含分配标签头。malloc 后端元数据、IO 缓冲/栈与运行时另由真实进程内存体现。payload≤32KiB **不是实际总 RAM 的证明**；payload>32KiB 则足以否定该过滤器状态预算。

原作者 getMemory 只按 map 键/指针与 snapshot 部分尺寸统计，漏掉 puBFMap BF 位图等；保留作辅助列，不用于预算判断。没有静默删除 BF、停止覆盖或把预算耗尽后的 fail-open 当原算法。

## 3. 验证集选择结果

unconstrained_initial 按 30k 验证 FP 选择；initial_32k 只从 30k 请求状态峰值≤32KiB 的候选选择。平局按初始请求峰值及参数确定，不用测试集、40k 未来 FPR/内存或计时筛选。峰值包含临时态，不只稳态。表中的 author_reported_final_B 是作者函数值，不能与真实追踪峰值混用。

|   seed | order        | selection             |   bits |   k |   depth |    p |   val_FP_initial |   test_FP_initial |   test_FP_final |   initial_peak_payload_B |   peak_payload_B |   author_reported_final_B |   first_budget_violation_key |
|-------:|:-------------|:----------------------|-------:|----:|--------:|-----:|-----------------:|------------------:|----------------:|-------------------------:|-----------------:|--------------------------:|-----------------------------:|
|      7 | random       | author_default        |   1024 |   3 |      30 | 0.01 |               18 |                58 |              69 |                  6132396 |          6132396 |                    403248 |                          315 |
|      7 | random       | unconstrained_initial |   4096 |   7 |       8 | 0.01 |                3 |                10 |              40 |                   298084 |           298084 |                     40928 |                          107 |
|      7 | random       | initial_32k           |   4096 |   3 |       4 | 0.01 |              546 |              1604 |            2755 |                    19828 |            19828 |                      9440 |                            0 |
|      7 | length_shift | author_default        |   1024 |   3 |      30 | 0.01 |               14 |                37 |              69 |                  5203664 |          5203664 |                    403248 |                          310 |
|      7 | length_shift | unconstrained_initial |   4096 |   3 |       8 | 0.01 |                9 |                56 |             111 |                   298784 |           298784 |                     51872 |                          105 |
|      7 | length_shift | initial_32k           |   4096 |   3 |       4 | 0.01 |              383 |              1139 |            2755 |                    20528 |            20528 |                      9440 |                            0 |
|     19 | random       | author_default        |   1024 |   3 |      30 | 0.01 |               20 |                53 |              71 |                  6161796 |          6161796 |                    402480 |                          337 |
|     19 | random       | unconstrained_initial |   4096 |   7 |       8 | 0.01 |                5 |                13 |              33 |                   298084 |           298084 |                     40928 |                          124 |
|     19 | random       | initial_32k           |   4096 |   3 |       4 | 0.01 |              571 |              1627 |            2762 |                    19828 |            19828 |                      9440 |                            0 |
|     19 | length_shift | author_default        |   1024 |   3 |      30 | 0.01 |                9 |                46 |              71 |                  5185716 |          5185716 |                    402480 |                          337 |
|     19 | length_shift | unconstrained_initial |   1024 |   3 |       8 | 0.01 |                9 |                46 |             108 |                   102708 |           103540 |                     53216 |                          542 |
|     19 | length_shift | initial_32k           |   4096 |   3 |       4 | 0.01 |              380 |              1112 |            2762 |                    19828 |            19828 |                      9440 |                            0 |
|     43 | random       | author_default        |   1024 |   3 |      30 | 0.01 |               20 |                55 |              71 |                  6124164 |          6124164 |                    403488 |                          316 |
|     43 | random       | unconstrained_initial |   4096 |   7 |       8 | 0.01 |                2 |                 8 |              29 |                   298084 |           298084 |                     40928 |                          128 |
|     43 | random       | initial_32k           |   4096 |   3 |       4 | 0.01 |              531 |              1677 |            2854 |                    19828 |            19828 |                      9440 |                            0 |
|     43 | length_shift | author_default        |   1024 |   3 |      30 | 0.01 |               14 |                40 |              71 |                  5228444 |          5228444 |                    403488 |                          316 |
|     43 | length_shift | unconstrained_initial |   4096 |   3 |       8 | 0.01 |               11 |                25 |              81 |                   298084 |           298084 |                     52448 |                          128 |
|     43 | length_shift | initial_32k           |   4096 |   3 |       4 | 0.01 |              386 |              1168 |            2854 |                    19828 |            19828 |                      9440 |                            0 |

作者默认配置峰值请求状态为 **5,185,716–6,161,796 B**，明显超过 32KiB。更小深度的候选可以降低需求，但所选 32KiB 候选在这个 URL ID/固定分类器场景的终点 FPR 达 22.958%–23.783%。这不是对所有 namespace/模型/DPBF 配置的下界，也不是证明该论文没有价值。

同数据上的固定 LBF 继续持有旧配置，是更强的低成本对照：

|   seed | order        |   fixed_LBF_hold_FP |   author_index_32k_FP | author_index_32k_FPR   |   author_peak_requested_B |
|-------:|:-------------|--------------------:|----------------------:|:-----------------------|--------------------------:|
|      7 | random       |                  63 |                  2755 | 22.958%                |                     19828 |
|      7 | length_shift |                  80 |                  2755 | 22.958%                |                     20528 |
|     19 | random       |                  88 |                  2762 | 23.017%                |                     19828 |
|     19 | length_shift |                  73 |                  2762 | 23.017%                |                     19828 |
|     43 | random       |                  60 |                  2854 | 23.783%                |                     19828 |
|     43 | length_shift |                  59 |                  2854 | 23.783%                |                     19828 |

这里比较端点查询质量及状态需求。它不证明当前 rolling 重配置优于动态 LBF 的端到端服务；本身低 FPR 的固定 BF 已有优势，且 DPBF 未获得联合阈值/模型调参机会，必须在扩大比较时补齐。

## 4. 测量与覆盖范围

378 次运行，初始化历史 30k、插入 10k；每次插入后立即查询，并最终全量验证 40k。累计立即查询 **3,780,000 次**、终点成员检查 **15,120,000 次**，所有 FN 为 0，退出时每个作者分配归零。存储的 ID/位图覆盖是可证明正确的结构性质；这些试验不穷尽执行或哈希碰撞情形。

5 次重复计时摘要（毫秒）如下。update 含历史文件读取、模型评分、插入及查询触发的 lazy snapshot 重构；本阶段顺序执行，没有 journal 写入和并发负载。不能拿它与三线程迁移计时直接计算性能倍率。过程逻辑 IO 与工作集/私有提交在原始行；没有物理冷 IO 声称。最高实测工作集 28,561,408 B，本基线不宣称强制 8MiB cap。

|   seed | order        | selection             |   initial_ms |   arrival_insert_query_ms |   process_cpu_ms |   process_peak_B |
|-------:|:-------------|:----------------------|-------------:|--------------------------:|-----------------:|-----------------:|
|      7 | random       | author_default        |       47.285 |                   385.020 |          453.125 |         16539648 |
|      7 | random       | unconstrained_initial |       20.804 |                    54.669 |           93.750 |          6918144 |
|      7 | random       | initial_32k           |       18.389 |                     4.535 |           31.250 |          6569984 |
|      7 | length_shift | author_default        |       39.009 |                   518.531 |          578.125 |         14831616 |
|      7 | length_shift | unconstrained_initial |       17.957 |                    78.271 |          109.375 |          6897664 |
|      7 | length_shift | initial_32k           |       16.610 |                     6.365 |           31.250 |          6557696 |
|     19 | random       | author_default        |       45.256 |                   373.933 |          437.500 |         16531456 |
|     19 | random       | unconstrained_initial |       20.332 |                    54.191 |           78.125 |          6922240 |
|     19 | random       | initial_32k           |       18.280 |                     4.475 |           31.250 |          6549504 |
|     19 | length_shift | author_default        |       38.379 |                   524.076 |          578.125 |         14848000 |
|     19 | length_shift | unconstrained_initial |       17.212 |                     6.720 |           31.250 |          6709248 |
|     19 | length_shift | initial_32k           |       16.341 |                     6.337 |           31.250 |          6565888 |
|     43 | random       | author_default        |       44.766 |                   379.653 |          437.500 |         16531456 |
|     43 | random       | unconstrained_initial |       20.183 |                    54.880 |           78.125 |          6905856 |
|     43 | random       | initial_32k           |       18.109 |                     4.411 |           31.250 |          6557696 |
|     43 | length_shift | author_default        |       38.335 |                   520.073 |          578.125 |         14835712 |
|     43 | length_shift | unconstrained_initial |       17.470 |                    76.721 |          109.375 |          6914048 |
|     43 | length_shift | initial_32k           |       16.434 |                     6.472 |           31.250 |          6553600 |

## 5. 对论文目标的影响

现在已有忠实双结构源码、修复记录、真实内存和调参证据，不能再用简单追加 BF 冒充 IA-LBF。但并发、公平联合配置、硬 cap 下的显式降级/可行性策略及同到达后端比较尚未完成。当前可支持的是：原作者默认实现的内存函数不能用于本任务的预算证明；这个稀疏 URL ID 场景中，该有限网格尚未获得同时满足低 FPR 和 32KiB 状态需求的实例。没有得出新的原创重配置算法，论文目标保持未完成。

复现入口：port_author_dpbf.py、author_baseline.cpp、run_author_baseline.py、author_baseline_report.py；协议 plan/author-baseline-protocol.md；完整命令、stdout/stderr、源码/数据哈希在 results/author-baseline-*；失败证据 results/author-wrap-failure.log。来源及容量前提见 plan/dynamic-baseline-spec.md。
