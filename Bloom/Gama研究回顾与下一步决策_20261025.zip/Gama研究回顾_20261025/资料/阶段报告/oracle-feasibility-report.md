# Oracle 回本验证：COD 的静态预算修正否掉了当前收益路径

2026-10-11。完成本轮“先算完美信息下的回本余量”的离线验证。没有新增完整 SQLite 服务实验，没有改进迁移器。研究目标保持 active；本报告不宣称算法或论文已经完成。

## 1. 最重要的结论

**此前 COD 的静态基线未用满预算，动态收益被高估。** 旧静态为 16×1536 B、k=8；模型占 5600 B、控制预留 1008 B。没有在线 score 目录的静态配置可以用

\[
m_{\mathrm{region}}=8\left\lfloor\frac{32768-1008-5600}{16\cdot8}\right\rfloor=1632\ \mathrm{B}.
\]

在线配置实际仍需 66×24=1584 B 的目录/统计状态，留给 BF 的预算较少；静态不需要支付这份常驻费用。本轮还搜索 k=1..16，而不是将 k=8 固定给新静态。

对 COD 完整既有候选边界搜索得到 k=7、block=1632、cut=2566043879964。全状态 32720 B。12m 请求产生 **125934** 次误查，明显少于旧静态 145317，也少于原布局族的最佳静态 144127。

URL 的同模型静态预算本来已经接近用满；重搜 14 个已有 cut×16 个 k 后，仍为 k=7、block=1936、cut=-8109611753865，32684 B。

这些是**同一固定模型、已有 cut 网格中的离线 hindsight 最优静态**，不是全模型/连续阈值/全部结构的全局最优。oracle 也使用未来查询信息，因此该比较用于机会分析，不是在线学习评价。不能将测试轨迹最优配置直接发布为无泄漏在线算法。

## 2. 实际做了什么

1. 重用此前 native 生成且成员 FN=0 的 6 个 URL /45 个 COD 动态 endpoint flags；按原 seed、90% 负查询、两段 9:1→1:9 组比例，逐请求重放。
2. 分别分析 600k、2.4m、12m 请求；按 20k/s 仅对应**逻辑** 30/120/600 s，没有实际等候该时长。
3. 计算免费单次上调、免费每 10k 切换和免费每请求选状态三种 oracle；最后一种极度乐观，不满足实际迁移/内存条件。
4. 批量测既有 warm replay、线程启动、查询/BF/统计/选择核心、初始构建，以及真实 hot SQLite 负查找 CPU。短批次分辨率不足，因此仅对同组件延长批次至 20m 次；没有扩大服务方案或数据规模。
5. 修正静态预算，离线搜索 URL 224、COD 1056 个静态配置。直接使用预计算 score/hash，一次读取 key 后复用，记录真实离散位图查询结果；没有用 Eq.3 预测代替 endpoint FPR。
6. 用原有 `pool_flags.exe` / `JointService::query` 对选出的静态配置交叉验证；六组 weighted misses 均一致。

每个静态配置完整检查 45k 成员 FN=0。静态搜索最大工作集 URL 14364672 B、COD 15822848 B；服务状态预算与离线进程内存是不同概念，不能称整个离线搜索只用 32 KiB。组件进程也受原 32 MiB job 配额约束，prepared packets 不计作部署的新辅助状态。

## 3. 完美信息能省多少误查？

| 数据集 / 请求数 | 修正静态 | 免费单次上调（10k 发布格点） | 相对静态节省 | 免费每 10k 任意切换 |
|---|---:|---:|---:|---:|
| URL 600k | 3664 | 3053 | 611 | 3044 |
| URL 2.4m | 14508 | 12221 | 2287 | 12199 |
| URL 12m | 71662 | 61351 | 10311 | 61192 |
| COD 600k | 6285 | 6573 | -288 | 6426 |
| COD 2.4m | 24851 | 26460 | -1609 | 25777 |
| COD 12m | 125934 | 132699 | **-6765** | 129602 |

再让单次上调 oracle 在**任意请求之间发布**，COD 12m 的最优误查为 **132698**，仍比修正静态多 **6764**。所以 COD 失败不是 10k 格点导致错过发布时间。

“每 10k 任意切换”还允许下调和瞬时重建，无费用，已比实际协议宽松；它在 COD 上仍比修正静态多 3668 次误查。但逐请求自由选择 endpoint 的极端 oracle 为 26472，不能据前述结果否定全部配置机制、全部节奏或全部 LBF。它也没有提供部署这些 endpoint 所需的 RAM 或历史访问算法。

## 4. 单次上调原型的精确否证范围

设候选 endpoint 的负查询接受标记为 a_j(i)，初始为 a_0。固定目标 j、发布位置 p，免费瞬时动作的误查数是

\[
M_j(p)=\sum_{i<p}a_0(i)+\sum_{i\ge p}a_j(i)
=\sum_i a_j(i)+\sum_{i<p}(a_0(i)-a_j(i)).
\]

逐请求前缀最小值精确给出 min_p M_j(p)，再枚举全部 45 个 COD endpoint。实现采用 signed 差值，重复 key 按查询次数计；不将 uint8 的负差值溢出当正数。

现有 Partial 在发布前仍用旧阈值，位图只做 OR，故其接受标记至少为 a_0；发布后为 a_j。于是实际单次 Partial 的 M 不小于上述免费最优值。对本轮 COD 族，这个最优值已经高于修正静态。

因此，**固定模型8、k=8、1536 B 区域、当前45个上调候选的单次 Partial，不能靠减少误查偿还非负维护费用**。这是明确有限范围的结论。总 CPU 还可能包含负的查询路径费用差，不能由误查数单独排除它；模型/布局/k 变化、不同初始状态、多次动作、区域异步组合与可删除新结构不由此证明否定。

## 5. CPU 回本曲线怎样收费

没有从整轮 CPU 差值反推 K，也没有将 Windows thread cycles 按标称 GHz 转成 CPU 秒。

本轮采用两条**已测组件的保守收费模型**：

- oracle plain：动态付全额 prepared-query/BF 核心、初始构建、额外 score index 建立、warm replay 与线程启动费用。
- controller core：在上述基础上，付既有统计、价格计时和选择核心；价格数值仅用于覆盖选择分支，是模拟输入，不是实测后端价格或新决策结果。

两条模型都让静态免费获得这些已测查询组件和初始化，不用跨配置微小 CPU 差值争胜。相同固定模型的评分/hash 工作在两边共同省去。诊断、运行状态检测/同步细节，以及共同工作受缓存/并发影响后的差额仍未完整证明；因此这些不是完整部署 K 的确定上界。未测费用作为显式残余参数 0/10/50/100 ns 每请求进入曲线。

测量以三批的 min/max 加 CPU clock 一量子的误差形成敏感性区间，**不是置信区间**。COD 部分组件在运行顺序中有明显速度变化，不能用点值排序策略。warm replay 不包含服务竞争，额外的 benchmark bitmap 恢复也在它的费用内；实际并发价格和冷盘重放可能更贵。

过渡误查另按此前 URL 12k /COD 6k 请求跨度的 old OR target 条件计算。oracle 可以知道变化时间，故在选定发布点前一个跨度启动回放，过渡附加量相对旧 endpoint 计算。收费曲线是这一条件日程，不是对全部迁移日程的最优性证明。这些跨度是条件参数，**不是新后端的确定发布延迟界**。

### URL 的收费回本点

| 收费模型 | CPU c* 点值 | 测量敏感性范围 |
|---|---:|---:|
| oracle plain，全部已测组件收费 | 41.15 us/误查 | 37.70–45.23 us |
| controller core，全部已测组件收费 | 48.46 us/误查 | 45.47–52.09 us |

这里只报收费模型的 c*，不称完整部署 c*。上述提前启动的条件日程将 URL 的误查节省降至 10258、COD 降至 -6803。按较高费用包络、每次误查 100 us CPU，URL controller core 仍容许约 40.96 ns/请求的未计费用，超过该余量就可能失去回本。该预算是参数化结果，不是现有部署测量。

COD 在此相同误查费用模型中没有正 c 的回本点，因为 Delta M<0 且所收费组件为正；它不等价于前节未计查询差额下的完整 CPU 不可能性。

实际 hot SQLite 组件校准：URL 18.83–21.48 us CPU/次，COD 14.14–15.00 us CPU/次（不同组比例点值）。仅测试 8192 个既有负 key 的 warm 重复查找、256 KiB SQLite cache，且包含调用准备，不可当整个后端的通用单价。它们仍低于 URL 的全额组件收费回本点；这不构成真实整轮胜负验证。磁盘或远程 KV 的等待时间不能直接代入 CPU c*。

![Oracle 机会与 CPU 收费曲线](../图片/oracle-opportunity-oracle-break-even.png)

## 6. 回本与系统改善幅度是两道门槛

12m 请求里有 1.2m 真成员查询，所有正确过滤器都需访问后端。在相同单价、后端访问占主导且忽略全部迁移费用时，URL 单次上调最多减少

\[
\frac{10311}{1200000+71662}=0.8108\%
\]

的后端访问工作。即便免费每 10k 换配置也只有 0.8233%。这不是任意硬件/异质 lookup 下的延迟上界，但说明当前 10% 成员查询、同价假设限制了故事强度。COD 修正静态下单次动态的访问工作增加约 0.5102%，并非减少。

保持负查询条件分布、仅改变混合比例的反事实计算另保存在 query-mixture-sensitivity.csv。URL 全负查询时单次动作的最多相对误查节省约 14.39%；这不是实测新 workload，也不能不支付迁移费用就声称系统改善。

之前“要求至少20%净收益余量”的提议应明确为节省费用相对额外费用的 ROI 裕量，而非整套服务至少快20%。二者不可混用。本批负载在后端同价极限下甚至没有后者的机会。

## 7. 本轮决定与下一步边界

**当前两数据集 B 配置未通过可行性门槛。** 停止继续优化该固定布局的估计器和迁移速度，也不根据本轮结果直接换 CBF/CF 包装算法。

本轮最有价值的新线索是：在线优化需要的常驻统计/索引内存，会挤占过滤器位图，可能让连免费 oracle 都输给无需该状态的静态配置。此前笼统“静态更好/动态不回本”应改成这个有明确预算原因、可独立检查的结论。

它是进一步研究的问题，尚未查明是否原创、是否在完整 COD/Yelp/URL 与其他预算上普遍，也没有解决完整 Gama/CLBF 的模型选择。C 不能因此自动成为论文。后续若继续投稿目标，应先验证这个单一机制的规模与方法边界，并与 CLBF 和已有评测区别；不以本轮 45k 成员结果代替最终规模实验。导师会议与组内后续信息仍未确定，不阻止本轮已完成的证据交付。

## 8. 代码、日志与结果

- 机会重放：oracle_opportunity.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_opportunity.py`；未随阅读包附带）；opportunity.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-opportunity\opportunity.csv`；未随阅读包附带）、one-action-candidates.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-opportunity\one-action-candidates.csv`；未随阅读包附带）。
- 完整预算静态搜索：oracle_static_grid.cpp（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_static_grid.cpp`；未随阅读包附带）、oracle_static_run.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_static_run.py`；未随阅读包附带）；static-grid.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-static-budget\static-grid.csv`；未随阅读包附带）、best-static.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-static-budget\best-static.csv`；未随阅读包附带）、native URL 日志（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-static-budget\url\run.json`；未随阅读包附带）、native COD 日志（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-static-budget\cod\run.json`；未随阅读包附带）。
- 原查询实现交叉核验：oracle_static_verify.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_static_verify.py`；未随阅读包附带）；parity.json（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-static-budget\parity.json`；未随阅读包附带）。
- 短组件批次：oracle_component_cost.cpp（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_component_cost.cpp`；未随阅读包附带）、oracle_component_run.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_component_run.py`；未随阅读包附带）；raw.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-components\raw.csv`；未随阅读包附带）、spec.json（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-components\spec.json`；未随阅读包附带）。
- 分辨率修正与初始/后端校准：oracle_refined_run.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_refined_run.py`；未随阅读包附带）、生成的 C++（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_component_refined.cpp`；未随阅读包附带）；raw.csv（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-components-refined\raw.csv`；未随阅读包附带）、URL 日志（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-components-refined\url-run.json`；未随阅读包附带）、COD 日志（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-components-refined\cod-run.json`；未随阅读包附带）。支持头是旧 cadence 源在 main 之前的精确前缀。
- 回本模型与图：oracle_break_even.py（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\oracle_break_even.py`；未随阅读包附带）；收费账本（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-break-even\charged-ledger.csv`；未随阅读包附带）、曲线（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-break-even\curves.csv`；未随阅读包附带）、后端访问比例（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-break-even\backend-access-ceilings.csv`；未随阅读包附带）、hot CPU（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\oracle-break-even\hot-lookup-calibration.csv`；未随阅读包附带）、SVG（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\figures\oracle-opportunity\oracle-break-even.svg`；未随阅读包附带）。

实际运行顺序：opportunity 初版 → component_run → refined_run → static_run → 原查询交叉验证 → opportunity 修正版 → break_even。复现应先建立新静态结果再重放 oracle；驱动在结果目录已存在时停止以保护既有日志。所有新 native 进程最终返回0；一次组件初编译的 main 宏冲突在执行前修正，原静态网格编译还有一条非致命缩进警告，未据此伪称 warning-free。

### 复现入口（PowerShell）

以下命令依赖本仓库已保存的模型、45k 成员、查询池、score 分桶索引与 `pool_flags.exe`。完整重新执行请使用保留这些输入、但尚未创建三个新结果目录 `oracle-components`、`oracle-components-refined`、`oracle-static-budget` 的工作副本；不要覆盖本次原始日志。Python 使用 NumPy、pandas、Matplotlib；native 使用 MinGW C++17、Windows PSAPI 和现有 SQLite DLL。

```powershell
Set-Location -LiteralPath 'E:\Projects\CPP_Learing_CS106X\Bloom\research\round2'
& 'C:\Program Files\mingw64\bin\g++.exe' -std=c++17 -O3 -Wall -Wextra -pthread -I 'E:/Conda/Library/include' oracle_component_cost.cpp -o oracle_component_cost.exe -lpsapi
& 'E:\Conda\python.exe' oracle_component_run.py
& 'E:\Conda\python.exe' oracle_refined_run.py
& 'E:\Conda\python.exe' oracle_static_run.py
& 'E:\Conda\python.exe' oracle_static_verify.py
& 'E:\Conda\python.exe' oracle_opportunity.py
& 'E:\Conda\python.exe' oracle_break_even.py
```

只从既有结果重新计算机会和图表，可执行最后两行；这会更新派生 CSV/图，不重新测量服务或后端。各 native 实际参数和 stdout/stderr 保存在对应 `run.json` 中。
