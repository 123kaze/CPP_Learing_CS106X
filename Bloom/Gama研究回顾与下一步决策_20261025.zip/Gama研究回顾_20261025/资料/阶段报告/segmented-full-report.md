# 补强 Full 基线：分区与历史组织消除了大部分退化

2026-10-11。完成两个已有机制的 Full 对照：逐区域 fail-open、以及按区域组织缓存 score 的单遍前缀回放。它们是公平基线，不是新算法贡献。本轮没有增加预测模块、模型或候选集合。

## 1. 实现与收费

**16 遍分区 Full（mode4）。** 保留原 score 桶，每次只清空一个区域，扫描全部目标保护成员并挑出本区域 key。完成后关闭该区域，再处理下一个。最多一个区域 open；每条目标历史被读/哈希 16 次，全部记录和字节收费。没有辅助历史索引。

**区域前缀 Full（mode5）。** 将同一缓存 score/key 历史按 hash 区域拆成 16 个文件，并按原 score 桶顺序存放；为每个候选 cut 写入本区域的累计字节位置/记录数。选择 cut 后读取每区域对应前缀，目标保护成员总共访问一次。相同模型、k、位图布局、成员和候选阈值；没有额外重评分或双倍 BF。

mode5 的辅助文件与元数据另建于自己的结果目录，原实验文件不改。初始化成本包括原 score index 建立、辅助索引建立与元数据复制；后两项不是免费。服务仍执行同一 10k 检查、无阶段重置、相同价格反馈与费用代理。mode4 预测扫描数为 16×目标保护数，mode5 为目标保护数。

| 数据集 | 辅助建索引读/写 | 实测辅助 CPU | 实测辅助 wall | 外部辅助文件 |
|---|---:|---:|---:|---:|
| URL | 3,340,564 / 3,343,864 B | 0.031250 s | 31.56 ms | 16 data + 16 prefix metadata |
| COD | 1,396,596 / 1,411,960 B | 0.062500 s | 48.90 ms | 同上 |

CPU 分辨率较粗，短建立阶段可出现 CPU 点值大于 wall，不将它们混用或排序。元数据复制的 CPU/wall/字节也保存在日志。数据文件不严格逐 score 排序，而是按有序 score 桶排列；**仅目录中既有 cut** 对应精确前缀，不能任意 threshold 截断。

## 2. 安全性与内存论证

固定成员 S、固定模型 f、hash/k/m；区域 r 的目标保护集合为 \(P_r=\{x\in S:region(x)=r, f(x)\leq\tau_1\}\)。每个区域依次：

1. 在服务锁内设置该区域 open，再清空其位图并设置目标阈值。
2. 锁外读取历史，在锁内插入 \(P_r\) 的 key。
3. 覆盖全部 \(P_r\) 后，在锁内关闭 open。

尚未处理区域保持旧状态，已处理区域保持完整新状态，处理中的唯一 open 区域直接放行。故任一成员查询要么由旧/新有效状态接受，要么由 open 放行；区域关闭后，\(f(x)>\tau_1\) 的成员由模型接受，其余已在 BF 中。因此固定集合下 zero-FN；清除原位图无需第二份 BF。

位图区域物理地址不变、互不重叠；清除当前区域不触碰模型、其他位图或目录。mode4/5 未改变 32 KiB 模型/BF/目录/控制状态预留。活跃元数据 998/1002 B≤1008 B；在本轮四臂中最大 private 24,977,408 B、工作集 24,543,232 B，均低于单独的 32 MiB 进程额度。IO 缓冲、输入池、诊断等均受进程额度约束，不能称整个程序 32 KiB。

**此证明与新辅助索引限于固定成员集合。** mode5 文件是静态快照，未实现插入时前缀位置维护、journal、恢复或模型改变；不能把本轮推成并发插入支持。此前普通 score 桶的插入压力证据不自动适用于此辅助布局。

## 3. 真实执行结果

本轮四个 12m 请求臂、4.8m 成员查询，查询 FN=0，最终全部 45k 成员校验 FN=0。最终 bitmap 分别与独立重建、先前 Partial、全局 Full 和另一分区 Full 逐字节相同。每臂 1199 个检查点，一次动作在 6.01m 请求，目标均沿用冻结选择。

| 数据集/执行器 | 历史记录数 | 记录字节 | fail-open 请求 | 迁移 wall |
|---|---:|---:|---:|---:|
| URL Partial（此前首轮） | 5,381 | 717,116 | 0 | 11.95 ms |
| URL 全局 Full（此前） | 23,503 | 2,064,073 | 165,170 | 3534.92 ms |
| URL 分区 16 遍 | 376,048 | 33,025,168 | 9,377 | 779.50 ms |
| URL 分区前缀单遍 | 23,503 | 2,064,073 | 1,071 | 93.83 ms |
| COD Partial（此前首轮） | 5,057 | 156,767 | 0 | 6.08 ms |
| COD 全局 Full（此前） | 20,393 | 632,183 | 109,868 | 2159.37 ms |
| COD 分区 16 遍 | 326,288 | 10,114,928 | 6,640 | 532.57 ms |
| COD 分区前缀单遍 | 20,393 | 632,183 | 960 | 75.64 ms |

mode4 记录数与预测 16×保护集一致；mode5 精确等于全局 Full 保护集。表内字节是实际解析的历史记录字节，mode5 另请求 16 个前缀位置（合计 320 B），stdio 预取与 backend 页面读取计入服务进程 ReadTransfer；它们不是物理冷盘 IO 数。

Full 更合理的组织显著缩小了先前全局 fail-open 开销。Partial 仍少读历史，且这个上调操作可直接 OR，完全不需要 open；但不能把最差全局 Full 的数千毫秒作为比所有重建优越的证据。

## 4. 完整 CPU 仍不能建立收益结论

含初始化、查询、统计、价格观察、选择、后台完成及额外索引建立费用的点值如下：

| 数据集 | Partial 两轮 | 全局 Full | 16 遍 Full | 单遍前缀 Full |
|---|---:|---:|---:|---:|
| URL | 29.6875 / 30.53125 s | 34.171875 s | 31.296875 s | 29.8125 s |
| COD | 29.34375 / 29.84375 s | 31.296875 s | 29.4375 s | 28.828125 s |

新 Full 的点值已与 Partial 接近，COD 单次还低于两个 Partial 点值。时间来自不同臂，运行变动与公共查询成本未独立归因；**不据单次比较给两者排名**。先前 Partial 相对静态的 CPU 符号翻转/两数据集门槛失败，不能由补基线自动变成成功。

同样，所有运行是约半分钟完成的闭环 12m 请求，仍非实际 600 s、真实查询日志、持续插入或冷存储。完整联合 Gama 选择、特征抽取成本和原创性尚未解决。

## 5. 对 B 的意义

重配置费用不能仅写成“replay 多少 key×统一常数”：历史组织改变读取次数，执行器改变 fail-open 的查询范围，查询/回放又共享服务锁。新证据要求费用模型按**操作与历史布局**区分，且辅助组织的建立/维护费用必须收费。该判断不能直接声称原创，已有分区/索引技术需要作为强基线。

本批执行器对照结束。下一步若继续 B，应先解决候选收益与执行费用能否便宜且可信地估计，并确定真实慢后端/实际时间跨度的合理测试条件；不继续堆同类热 SQL 次数。模型/BF 比例变化、稳定两数据集端到端收益、全范围 10× 选择降本与原创性门槛仍未通过。论文目标 active。

## 6. 资产

- 16 遍 Full 生成器（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\segmented_cadence_generate.py`；未随阅读包附带）、服务代码（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\indexed_sql_segmented.cpp`；未随阅读包附带）、执行器（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\segmented_cadence_run.py`；未随阅读包附带）、日志（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\segmented-cadence.log`；未随阅读包附带）。
- 区域前缀辅助构建（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\shard_prefix_build.cpp`；未随阅读包附带）、单遍服务生成器（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\shard_prefix_cadence_generate.py`；未随阅读包附带）、服务代码（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\indexed_sql_shard_prefix.cpp`；未随阅读包附带）、执行器（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\shard_prefix_cadence_run.py`；未随阅读包附带）、日志（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\shard-prefix-cadence.log`；未随阅读包附带）。
- 对照结果表（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\shard-prefix-native\baseline-comparison.csv`；未随阅读包附带）、辅助建立/完整结果（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\shard-prefix-native\summary.json`；未随阅读包附带）、逐检查点（原项目路径：`E:\Projects\CPP_Learing_CS106X\Bloom\research\round2\results\shard-prefix-native\decisions.csv`；未随阅读包附带）。

独立检查了每条辅助记录的 score 桶边界/hash 区域、每 cut 的累计成员和字节与原目录一致、文件/source/binary 哈希，以及生成器与执行代码逐字节一致。所有 endpoint 位图相同；没有为这些验证添加新的审计层。
