# Gama仓库PLBF静态基线：单备份重配置的机会被进一步压缩

2026-10-12。采用本地Gama仓库原样MaxDivDP、ThresMaxDiv、OptimalFPR_M；仅适配直方图输入和原生整数BF布局。不是CLBF，也不是作者Python BF库的性能复现。未使用独立测试选择配置。

## 1. 实际端点与组件费用

N50等概率分数bins，尝试1..5分区按验证解析FPR选择；初始／当前均选5分区。初始阈值概率[0,.52,.54,.56,.58,1]与当前相同，但BF空间和hash变化。初始布局中最高分区BF47496B/k1；当前clean该区恒accept，空间给其余区。

| 状态 | 独立测试误查／999996 | FPR % | 负查询组件CPU μs | 成员组件CPU μs |
|---|---:|---:|---:|---:|
| initial | 16588 | 1.6588 | 0.1027–0.1088 | 0.0879–0.0879 |
| hold | 25235 | 2.5235 | 0.1063–0.1063 | 0.0879–0.0879 |
| clean | 18551 | 1.8551 | 0.1002–0.1014 | 0.0195–0.0244 |

三个状态各两种顺序、六原生进程全终态0；完整成员FN0，验证cached/raw接受计数一致，测试计数重复相等。核心262140B≤256KiB、实际元数据360B≤2048B预留、WS/Job commit≤32MiB。当前Hold完全沿用初始5分区阈值/bit长度/hash，只补插新增成员；没有访问最终分布重新分配静态BF。当前clean是另一个端点参考，不混作初始静态配置。

## 2. 免费瞬时single-backup重配置也要先过静态基线

沿用90%负/10%成员的条件CPU公式。c是同价后端误查CPU参数；不同端点的误查集合实价尚未全部测量。以下差额还没扣选择、迁移或同期统计，所以只是毛机会，负值不能靠延长时间摊销修复。

| c CPU μs | clean目标树数 | 相对初始PLBF Hold的6000万请求毛CPU信用 s |
|---:|---:|---:|
| 10 | 1 | -0.947–-0.881 |
| 10 | 4 | -1.234–-1.205 |
| 10 | 48 | -11.081–-10.780 |
| 20 | 1 | -2.171–-2.105 |
| 20 | 4 | -1.866–-1.837 |
| 20 | 48 | -7.262–-6.962 |
| 50 | 1 | -5.845–-5.779 |
| 50 | 4 | -3.763–-3.734 |
| 50 | 48 | 4.193–4.493 |
| 100 | 1 | -11.969–-11.903 |
| 100 | 4 | -6.925–-6.896 |
| 100 | 48 | 23.285–23.585 |

**直接否证：**独立测试上，初始PLBF补插后的Hold只有25235次误查，已经少于single-backup 1树clean的27503和4树clean的26406。c=20μs的条件账本下，这两个clean端点即使免费瞬时迁移也不优于PLBF Hold。之前固定1树Hold→clean约3秒扣费后信用是相对较弱single-backup Hold的机会，不能作为B在强基线上有效的证据。

48树clean误查18164比PLBF Hold少7071，但更慢的模型会消耗该信用；不能再默认多训练/更低FPR就值得支付迁移费用。完整CLBF可能提供更强对照，本次并未关闭其门槛。

## 3. 决定与研究边界

停止为上述固定1树single-backup case开发选择器或扩大在线重复试验。B整体未被否定：PLBF自身Hold→clean仍有分区内存/hash重配置机会；已有分区优化、CLBF静态联合优化和动态learned filter方法须比较，不能把普通水位分配/历史账本包装原创。本报告未核实“动态CLBF重配置已被解决”。C亦不能因存在反例就自动成为论文。

本对照沿用局部全COD600万原始记录／300万成员定义，与Gama原论文预处理计数不同；成员增长与请求负载为合成时间线。离线配置／缓存生成RAM单列，不属于32MiB原生服务。PLBF查询组件批次128记录×32遍摊薄原始输入IO，不是完整查询延迟。

## 4. 交付与方法核查

源码full_cod_plbf_select.py、full_cod_plbf_native.cpp、full_cod_plbf_run.py、full_cod_plbf_analyze.py。协议plan/full-cod-plbf-control-protocol.md；作者优化源在../../LBF-Gama/plbf/utils/，SHA与描述符均在selection-profile.json/native-sources.json。
原始results/full-cod-plbf-control/selection.json/selected.json/descriptor-0.txt/descriptor-2.txt、六个case的stdout/stderr/run.json、complete.json；派生summary.csv/counterfactual.csv。
验证直方图输入与原prList定义等价：作者按bisect_left划分(score_l,score_r]；本实现quantized cut对应同一50个概率边界，并对所有成员/验证逐条检查sigmoid浮点与tick区间分配一致。将这组count/total及累积和写入同一prList对象，MaxDivDP与OptimalFPR_M未修改。
整数转换：每BF连续长度向下取8B，余下8B按估计FPR边际下降分配；整数k穷举1..16。这不保证原生FPR全局最优；特别是最高分区理想hash可能小于1，原生必须至少1。保留解析与实际差异，不声称完整作者复现或替代CLBF。

相关结构边界：CLBF交替trunk/branch/final过滤，并通过DP选深度与BF参数；单阶段PLBF只是其可表达的一个结构。本次没有实现这一DP级联，不能把PLBF重命名为CLBF。[CLBF原论文§3与附录A](https://arxiv.org/html/2502.03696v1)。
