"""Stream cumulative margins once; preserve counts and terminal native logs."""
import json,subprocess,time
from pathlib import Path
from full_cod_prepare import DEST
from full_cod_plbf_select import sha,bounds,DT
import numpy as np
ROOT=Path(__file__).resolve().parent
OUT=DEST.parent/'full-cod-gplbf-joint'
def main():
    assert not OUT.exists();OUT.mkdir();(OUT/'hist').mkdir()
    command=['C:/Program Files/mingw64/bin/g++.exe','-std=c++17','-O3','full_cod_gplbf_hist.cpp','-o','full_cod_gplbf_hist.exe','-lpsapi']
    b=subprocess.run(command,capture_output=True,text=True)
    (OUT/'hist-build.json').write_text(json.dumps(dict(command=command,returncode=b.returncode,stdout=b.stdout,stderr=b.stderr),indent=2));assert b.returncode==0,b.stderr
    sources={str(p):sha(p) for p in [ROOT/'full_cod_gplbf_common.hpp',ROOT/'full_cod_gplbf_hist.cpp',ROOT/'full_cod_gplbf_hist_run.py',ROOT/'full_cod_gplbf_hist.exe',ROOT/'plan/full-cod-gplbf-protocol.md',DEST/'models/model48.bin']}
    (OUT/'hist-sources.json').write_text(json.dumps(sources,indent=2));start=time.perf_counter()
    command=[str(ROOT/'full_cod_gplbf_hist.exe'),str(DEST/'models/model48.bin'),str(DEST/'data'),str(OUT/'hist')]
    with (OUT/'hist-stdout.log').open('x') as out,(OUT/'hist-stderr.log').open('x') as err:
        p=subprocess.Popen(command,stdout=out,stderr=err);(OUT/'hist-process.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2));code=p.wait()
    (OUT/'hist-run.json').write_text(json.dumps(dict(returncode=code,command=command,wall_seconds=time.perf_counter()-start),indent=2));assert code==0,(OUT/'hist-stderr.log').read_text()
    cuts=np.array([int(np.floor(np.log((j/100)/(1-j/100))*(1<<44))) for j in range(1,100)]+[(1<<63)-1],dtype=np.int64)
    checks=[]
    for name in ('initial','early','late','validation'):
        path=OUT/f'hist/{name}.hist';head=np.fromfile(path,dtype='<u4',count=2);assert head.tolist()==[48,100]
        with path.open('rb') as f:f.seek(8);total=int.from_bytes(f.read(8),'little')
        hist=np.fromfile(path,dtype='<u8',offset=16).reshape(48,100);assert np.all(hist.sum(axis=1)==total)
        for d in (1,2,4,8,12,24,48):
            cached=np.memmap(DEST/f'scores/{name}-{d}.bin',dtype=DT,mode='r');count=np.zeros(100,dtype=np.int64)
            assert len(cached)==total
            for begin in range(0,total,100000):count+=np.bincount(np.searchsorted(cuts,np.asarray(cached['tick'][begin:begin+100000]),side='left'),minlength=100)
            assert np.array_equal(count,hist[d-1]),(name,d)
            checks.append(dict(population=name,depth=d,records=total,equal=True))
    (OUT/'hist-verification.json').write_text(json.dumps(dict(returncode=0,checks=checks,sources=sources),indent=2));print('All48 histograms; 28 cached-prefix comparisons agree',flush=True)
if __name__=='__main__':main()
