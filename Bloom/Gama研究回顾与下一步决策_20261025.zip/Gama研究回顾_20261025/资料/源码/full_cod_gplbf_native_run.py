"""Validation chooses first; selected layouts then receive isolated raw test."""
import json,struct,subprocess,time
import pandas as pd
from full_cod_gplbf_hist_run import ROOT,OUT
from full_cod_prepare import DEST
from full_cod_plbf_select import sha
FAMILY='Gama PLBF joint48'
def export_prefix(d):
    source=(DEST/'models/model48.bin').read_bytes();nr,nn=struct.unpack('<II',source[:8]);assert nr==48 and nn==48*29
    content=struct.pack('<II',d,d*29)+source[8:8+d*4]+source[8+48*4:8+48*4+d*29*24];path=OUT/f'model{d}.bin'
    if path.exists():assert path.read_bytes()==content
    else:path.write_bytes(content)
    return path
def freeze():
    assert json.loads((OUT/'profile-complete.json').read_text())['returncode']==0
    profiles=json.loads((OUT/'profile-rows.json').read_text());layouts=json.loads((OUT/'selected-layouts.json').read_text())
    # Explicitly exclude test columns from the old comparator before selection.
    prior=pd.read_csv(OUT.parent/'full-cod-clbf-control/finite-candidates.csv',dtype={'configuration':str},usecols=['family','configuration','method','rep','validation_fpr','filter_cpu_us','depth'])
    new=pd.DataFrame([dict(family=FAMILY,configuration=str(r['depth']),method=r['method'],rep=r['rep'],validation_fpr=r['validation_fp']/r['validation_n'],filter_cpu_us=.9*r['neg_cpu_us']+.1*r['pos_cpu_us'],depth=r['depth']) for r in profiles])
    finite=pd.concat([prior,new],ignore_index=True);finite.to_csv(OUT/'validation-candidates.csv',index=False)
    choices=[];required={}
    def add(depth,method,reason):required.setdefault((depth,method),[]).append(reason)
    for price in (10.,20.,50.,100.):
        work=finite.copy();work['cost']=work.filter_cpu_us+.9*work.validation_fpr*price
        a=work[work.method=='initial'].groupby(['family','configuration']).cost.mean().idxmin();b=work[work.method=='clean'].groupby(['family','configuration']).cost.mean().idxmin()
        choices.append(dict(price_cpu_us=price,initial_family=a[0],initial_configuration=a[1],target_family=b[0],target_configuration=b[1],rule='two-order mean raw validation CPU+empirical validation FP; no test columns'))
        if a[0]==FAMILY:
            d=int(a[1]);add(d,'initial',f'initial c{price}');add(d,'hold',f'hold c{price}');add(d,'clean',f'same-model target c{price}')
        if b[0]==FAMILY:add(int(b[1]),'clean',f'target c{price}')
    for stage,method in ((0,'initial'),(2,'clean')):
        r=new[new.method==method].groupby('depth').validation_fpr.mean().idxmin();add(int(r),method,'lowest validation FPR')
        if stage==0:add(int(r),'hold','Hold of lowest validation FPR')
    cases=[]
    for (d,method),reasons in sorted(required.items()):
        stage=0 if method=='initial' else 2;descriptor_stage=2 if method=='clean' else 0
        layout=next(r for r in layouts if r['stage']==descriptor_stage and r['depth']==d);model=export_prefix(d)
        cases.append(dict(id=f'{method}-{d}',method=method,stage=stage,depth=d,reasons=reasons,descriptor=layout['descriptor'],descriptor_sha256=layout['descriptor_sha256'],model=str(model),model_sha256=sha(model),layout=layout))
    (OUT/'validation-choices.json').write_text(json.dumps(choices,indent=2));spec=dict(cases=cases,choices=choices,profile_sha256=sha(OUT/'profile-rows.json'),scope='choices frozen before any new independent test query')
    (OUT/'native-spec.json').write_text(json.dumps(spec,indent=2));print('Validation choices frozen',choices,'native configurations',len(cases),flush=True);return spec
def main():
    assert not (OUT/'native-build.json').exists();spec=freeze()
    command=['C:/Program Files/mingw64/bin/g++.exe','-std=c++17','-O3','full_cod_gplbf_native.cpp','-o','full_cod_gplbf_native.exe','-lpsapi']
    b=subprocess.run(command,capture_output=True,text=True);(OUT/'native-build.json').write_text(json.dumps(dict(command=command,returncode=b.returncode,stdout=b.stdout,stderr=b.stderr),indent=2));assert b.returncode==0,b.stderr
    sources={str(p):sha(p) for p in [ROOT/'full_cod_gplbf_native.cpp',ROOT/'full_cod_gplbf_common.hpp',ROOT/'full_cod_gplbf_native_run.py',ROOT/'full_cod_gplbf_native.exe',ROOT/'full_cod_static_helpers.hpp',ROOT/'full_cod_cost_helpers.hpp',OUT/'native-spec.json']};(OUT/'native-sources.json').write_text(json.dumps(sources,indent=2));rows=[]
    cases=spec['cases']
    for rep,order in enumerate((cases,list(reversed(cases)))):
        for case in order:
            assert sha(case['descriptor'])==case['descriptor_sha256'] and sha(case['model'])==case['model_sha256']
            directory=OUT/f'native-{rep}-{case["id"]}';directory.mkdir();command=[str(ROOT/'full_cod_gplbf_native.exe'),case['model'],case['descriptor'],str(DEST/'data'),str(OUT.parent/f'full-cod-static-cost/members-{case["stage"]}.bin'),str(case['stage']),str(case['depth'])]
            start=time.perf_counter()
            with (directory/'stdout.log').open('x') as out,(directory/'stderr.log').open('x') as err:
                p=subprocess.Popen(command,stdout=out,stderr=err);(directory/'process.json').write_text(json.dumps(dict(pid=p.pid,command=command),indent=2));code=p.wait()
            (directory/'run.json').write_text(json.dumps(dict(command=command,returncode=code,wall_seconds=time.perf_counter()-start),indent=2));assert code==0,(directory/'stderr.log').read_text()
            got=[json.loads(line) for line in (directory/'stdout.log').read_text().splitlines()];assert len(got)==5;build,ep,neg,pos,test=got
            prof=next(r for r in json.loads((OUT/'profile-rows.json').read_text()) if r['rep']==rep and r['method']==case['method'] and r['depth']==case['depth'])
            assert ep['member_fn']==0 and ep['metadata_sizeof']<=2048 and ep['state_bytes']<=262144 and ep['bitmap_checksum']==prof['bitmap_checksum'] and neg['accepted']==prof['validation_fp']
            assert neg['records']==399536 and pos['records']==pos['accepted']==100000 and test['test_n']==999996 and max(test['process_peak_working_set'],test['job_peak_commit_bytes'])<=33554432
            if case['method']!='hold':assert ep['routed_counts']==[p['n'] for p in case['layout']['pieces']]
            row={**case,**ep,**test,'rep':rep,'validation_fp':neg['accepted'],'validation_n':neg['records'],'neg_cpu_us':neg['cpu_seconds']/neg['records']/32*1e6,'pos_cpu_us':pos['cpu_seconds']/pos['records']/32*1e6,'build':build,'negative_component':neg,'member_component':pos};rows.append(row)
            (OUT/'native-rows.json').write_text(json.dumps(rows,indent=2));print('Isolated Gama PLBF',rep,case['id'],'FP',test['test_fp'],'core',ep['state_bytes'],flush=True)
    for case in cases:
        r=[x for x in rows if x['id']==case['id']];assert len(r)==2 and r[0]['test_fp']==r[1]['test_fp'] and r[0]['bitmap_checksum']==r[1]['bitmap_checksum']
    (OUT/'complete.json').write_text(json.dumps(dict(returncode=0,native_processes=len(rows),sources=sources,scope='frozen48 prefix joint PLBF strong static control;no online migration/net ROI claim'),indent=2))
if __name__=='__main__':main()
