"""Four diagnostic batches, 48 states retained; no test and no serving claim."""
import json,subprocess,time
from full_cod_gplbf_hist_run import ROOT,OUT
from full_cod_prepare import DEST
from full_cod_plbf_select import sha
def main():
    assert json.loads((OUT/'selection-profile.json').read_text())['returncode']==0
    assert not (OUT/'profile-complete.json').exists();rows=[];references=[];runs=[]
    sources={str(p):sha(p) for p in [ROOT/'full_cod_gplbf_common.hpp',ROOT/'full_cod_gplbf_profile.cpp',ROOT/'full_cod_gplbf_profile.exe',ROOT/'full_cod_gplbf_profile_run.py',ROOT/'plan/full-cod-gplbf-protocol.md']}
    (OUT/'profile-sources.json').write_text(json.dumps(sources,indent=2));selected=json.loads((OUT/'selected-layouts.json').read_text())
    for rep,order in enumerate((('initial_hold','clean'),('clean','initial_hold'))):
        for state in order:
            directory=OUT/f'profile-{rep}-{state}';assert not directory.exists();directory.mkdir()
            command=[str(ROOT/'full_cod_gplbf_profile.exe'),str(DEST/'models/model48.bin'),str(DEST/'data'),str(OUT/'descriptors'),str(OUT.parent/'full-cod-static-cost'),state,str(rep)]
            start=time.perf_counter()
            with (directory/'stdout.log').open('x') as stdout,(directory/'stderr.log').open('x') as stderr:
                p=subprocess.Popen(command,stdout=stdout,stderr=stderr);(directory/'process.json').write_text(json.dumps(dict(command=command,pid=p.pid),indent=2));code=p.wait()
            run=dict(rep=rep,state=state,returncode=code,command=command,wall_seconds=time.perf_counter()-start)
            (directory/'run.json').write_text(json.dumps(run,indent=2));runs.append(run);assert code==0,(directory/'stderr.log').read_text()
            got=[json.loads(line) for line in (directory/'stdout.log').read_text().splitlines()]
            finish=got[-1];assert finish['kind']=='finish' and finish['diagnostic_only'] and max(finish['process_peak_working_set'],finish['job_peak_commit_bytes'])<=67108864
            eps=[r for r in got if r['kind']=='endpoint'];assert len(eps)==(48 if state=='clean' else 96)
            for ep in eps:
                name=ep['state'];d=ep['depth'];components=[r for r in got if r['kind']=='component' and r['configuration']==f'{name}-{d}'];assert len(components)==2
                neg,pos=components;assert neg['population']=='negative' and pos['population']=='member' and neg['records']==399536 and pos['records']==pos['accepted']==100000 and ep['member_fn']==0 and ep['state_bytes']<=262144
                layout=next(s for s in selected if s['stage']==(2 if name=='clean' else 0) and s['depth']==d)
                assert ep['state_bytes']==layout['state_bytes']
                if name!='hold':assert ep['routed_counts']==[p['n'] for p in layout['pieces']]
                rows.append(dict(rep=rep,method=name,**ep,validation_fp=neg['accepted'],validation_n=neg['records'],
                    neg_cpu_us=neg['cpu_seconds']/neg['records']/32*1e6,pos_cpu_us=pos['cpu_seconds']/pos['records']/32*1e6,negative_component=neg,member_component=pos,finish=finish))
            references.extend([dict(rep=rep,**r) for r in got if r['kind']=='component' and ('model48' in r['configuration'] or 'referencebf' in r['configuration'])])
            (OUT/'profile-rows.json').write_text(json.dumps(rows,indent=2));(OUT/'reference-rows.json').write_text(json.dumps(references,indent=2));print('Diagnostic batch complete',rep,state,'endpoints',len(eps),'wall',run['wall_seconds'],flush=True)
    for name in ('initial','hold','clean'):
        for d in range(1,49):
            r=[x for x in rows if x['method']==name and x['depth']==d];assert len(r)==2 and r[0]['bitmap_checksum']==r[1]['bitmap_checksum'] and r[0]['validation_fp']==r[1]['validation_fp']
    (OUT/'profile-complete.json').write_text(json.dumps(dict(returncode=0,diagnostic_batches=4,endpoints=len(rows),runs=runs,sources=sources,scope='all48 validation diagnostic profiles;64MiB aggregate;not serving or independent-test results'),indent=2))
if __name__=='__main__':main()
