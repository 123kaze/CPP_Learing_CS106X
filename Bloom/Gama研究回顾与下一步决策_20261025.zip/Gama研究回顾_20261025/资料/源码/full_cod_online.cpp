// Frozen-target, one-arena online screen. Regional fail-open is a known mechanism.
#define _WIN32_WINNT 0x0A00
#include "full_cod_cost_helpers.hpp"
#include "full_cod_sqlite.hpp"
double thread_cpu49(){FILETIME a,b,c,d;if(!GetThreadTimes(GetCurrentThread(),&a,&b,&c,&d))throw std::runtime_error("thread CPU");return(filetime(c)+filetime(d))*1e-7;}
void wait49(Clock::time_point base,uint64_t ns,HANDLE timer){auto deadline=base+std::chrono::nanoseconds(ns);
    for(;;){auto left=std::chrono::duration_cast<std::chrono::nanoseconds>(deadline-Clock::now()).count();if(left<=0)return;
        LARGE_INTEGER due;due.QuadPart=-std::max<int64_t>(1,(left+99)/100);
        if(!SetWaitableTimer(timer,&due,0,nullptr,nullptr,FALSE)||WaitForSingleObject(timer,INFINITE)!=WAIT_OBJECT_0)throw std::runtime_error("timer wait");}}
HANDLE timer49(){HANDLE t=CreateWaitableTimerExA(nullptr,nullptr,2,TIMER_ALL_ACCESS);
    if(!t)t=CreateWaitableTimerExA(nullptr,nullptr,0,TIMER_ALL_ACCESS);
    if(!t)throw std::runtime_error("timer");
    return t;}
uint64_t commit49(HANDLE job){JOBOBJECT_EXTENDED_LIMIT_INFORMATION stats{};
    if(!QueryInformationJobObject(job,JobObjectExtendedLimitInformation,&stats,sizeof stats,nullptr))throw std::runtime_error("job stats");
    return stats.PeakProcessMemoryUsed;}
struct Live49 {
    const Model&m;std::mutex mu;Filter49 filter{OLD49};std::array<int64_t,NS>cuts{};std::array<bool,NS>open{};
    explicit Live49(const Model&model):m(model){cuts.fill(OLD49);}
    bool maybe49(const Hash49&h)const{for(uint32_t j=0;j<K49;j++){auto p=(h.a+j*h.b)%(uint64_t(BLOCK49)*8);
        if(!(filter.bits[h.shard*BLOCK49+(p>>3)]&uint8_t(1u<<(p&7))))return false;}return true;}
    void add49(const Hash49&h){for(uint32_t j=0;j<K49;j++){auto p=(h.a+j*h.b)%(uint64_t(BLOCK49)*8);
        filter.bits[h.shard*BLOCK49+(p>>3)]|=uint8_t(1u<<(p&7));}}
    bool query(const Raw49&r,bool&is_open){auto h=hash49(r.id);
        {std::lock_guard<std::mutex>lock(mu);if(open[h.shard]){is_open=true;return true;}}
        int64_t tick=margin49(m,r);std::lock_guard<std::mutex>lock(mu);is_open=open[h.shard];
        return is_open||tick>cuts[h.shard]||maybe49(h);}
    bool cached_query(const Cached49&r){auto h=hash49(r.id);std::lock_guard<std::mutex>lock(mu);
        return open[h.shard]||r.tick>cuts[h.shard]||maybe49(h);}
};
struct Append49 {
    std::mutex mu;std::array<FILE*,NS>files{};std::array<std::array<char,IOBUF>,NS>buffers{};std::array<uint64_t,NS>bytes{};
    std::string path;
    explicit Append49(const std::string&p):path(p){for(int s=0;s<NS;s++){
        files[s]=fopen((path+"/journal"+std::to_string(s)+".bin").c_str(),"wb");
        if(!files[s]||setvbuf(files[s],buffers[s].data(),_IOFBF,IOBUF))throw std::runtime_error("journal output");}}
    ~Append49(){for(auto f:files)if(f)fclose(f);}
    void append(const Raw49&r,uint32_t shard){if(fwrite(&r,sizeof r,1,files[shard])!=1||fflush(files[shard]))throw std::runtime_error("journal append");bytes[shard]+=sizeof r;}
};
void fill_cached49(Live49&svc,const std::string&scores,int64_t cut){std::fill(svc.filter.bits.begin(),svc.filter.bits.end(),0);
    for(auto name:MEMBER49){Input49<Cached49>in(scores+"/"+name+"-48.bin");Cached49 r{};
        while(in.next(r))if(r.tick<=cut)svc.add49(hash49(r.id));}}
uint64_t fn_cached49(Live49&svc,const std::string&scores){uint64_t fn=0;
    for(auto name:MEMBER49){Input49<Cached49>in(scores+"/"+name+"-48.bin");Cached49 r{};while(in.next(r))fn+=!svc.cached_query(r);}return fn;}
void format49(Key&key,uint64_t id){key.len=uint32_t(snprintf(key.key,sizeof key.key,"%llu",(unsigned long long)id));}
int main(int argc,char**argv)try{
    if(argc!=11&&argc!=12)throw std::runtime_error("model data scores shards inserts db DLL output mode horizon_seconds [cache_kib]");
    HANDLE job=quotas();std::cout<<std::setprecision(17);Model model(argv[1]);
    if(model.roots.size()!=48||model.bytes()!=33600)throw std::runtime_error("fixed model");
    std::string data=argv[2],scores=argv[3],shards=argv[4],inserts=argv[5],output=argv[8],mode=argv[9];
    if(mode!="hold"&&mode!="full"&&mode!="regions")throw std::runtime_error("mode");
    uint64_t horizon=std::stoull(argv[10]),count=horizon*100000;
    SQLite sql(argv[7]);Backend writerdb(sql,argv[6],true),querydb(sql,argv[6],false);
    uint32_t cache_kib=argc==12?uint32_t(std::stoul(argv[11])):256;
    if(cache_kib!=256&&cache_kib!=8192)throw std::runtime_error("declared SQLite cache");
    if(cache_kib==8192){writerdb.exec("PRAGMA cache_size=-8192;");querydb.exec("PRAGMA cache_size=-8192;");}
    if(writerdb.number("SELECT count(*) FROM members")!=3000000)throw std::runtime_error("initial DB count");
    Live49 svc(model);size_t core=model.bytes()+NS*BLOCK49+2048;
    if(core>262144||sizeof(Live49)+sizeof(Model)>2048)throw std::runtime_error("core metadata");
    // One arena produces the frozen final reference, then is reused for the old state.
    auto prep=Clock::now();double prep_cpu=cpu_seconds();int64_t final_cut=mode=="hold"?OLD49:NEW49;
    fill_cached49(svc,scores,final_cut);
    {Input49<Raw49>in(inserts);Raw49 r{};while(in.next(r))if(margin49(model,r)<=final_cut)svc.add49(hash49(r.id));
        if(in.count!=1028)throw std::runtime_error("insert count");}
    {FILE*f=fopen((output+"/reference.bin").c_str(),"wb");if(!f||fwrite(svc.filter.bits.data(),1,svc.filter.bits.size(),f)!=svc.filter.bits.size()||fclose(f))throw std::runtime_error("reference");}
    fill_cached49(svc,scores,OLD49);if(fn_cached49(svc,scores))throw std::runtime_error("initial member FN");
    double prep_wall=seconds(prep),prep_cost=cpu_seconds()-prep_cpu;
    Append49 journal(output);std::atomic<bool>go{false},abort{false},reader_ready{false},writer_ready{false};
    std::exception_ptr reader_error,writer_error;Clock::time_point base;
    uint64_t requests=0,member_queries=0,wasted=0,accepted=0,open_queries=0,fn=0,db_miss=0,inserted=0,insert_fn=0;
    double query_cpu=0,writer_cpu=0,backend_wall=0,query_finish=0,writer_finish=0;
    // 100-request batches at1ms. No per-query spin waiting or hidden short logical horizon.
    std::thread reader([&]{try{
        Input49<Raw49>neg(data+"/evaluation.bin");Raw49 r{};Key key{};HANDLE timer=timer49();
        std::array<FILE*,3>member_files{};std::array<std::array<char,IOBUF>,3>buffers{};
        for(int j=0;j<3;j++){member_files[j]=fopen((data+"/"+MEMBER49[j]+".bin").c_str(),"rb");
            if(!member_files[j]||setvbuf(member_files[j],buffers[j].data(),_IOFBF,IOBUF))throw std::runtime_error("member input");}
        FILE*flags=fopen((output+"/query-flags.bin").c_str(),"wb");std::array<char,IOBUF>flagbuf{};
        FILE*lat=fopen((output+"/latency-sample.bin").c_str(),"wb");std::array<char,IOBUF>latbuf{};
        if(!flags||!lat||setvbuf(flags,flagbuf.data(),_IOFBF,IOBUF)||setvbuf(lat,latbuf.data(),_IOFBF,IOBUF))throw std::runtime_error("logs");
        reader_ready=true;while(!go.load()&&!abort.load())std::this_thread::yield();double cpu=thread_cpu49();
        while(requests<count&&!abort.load()){
            uint64_t deadline=(requests/100)*1000000;if(requests%100==0)wait49(base,deadline,timer);
            bool member=requests%10==0;
            if(member){uint64_t index=mix(member_queries^20261011ULL)%3000000;int file=0;
                if(index>=1999996){index-=1999996;file=1;if(index>=500177){index-=500177;file=2;}}
                if(_fseeki64(member_files[file],index*sizeof(Raw49),SEEK_SET)||fread(&r,sizeof r,1,member_files[file])!=1)throw std::runtime_error("member seek");
                member_queries++;
            }else if(!neg.next(r)){
                if(_fseeki64(neg.f,0,SEEK_SET))throw std::runtime_error("negative rewind");
                clearerr(neg.f);
                if(!neg.next(r))throw std::runtime_error("negative empty");}
            uint64_t start=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-base).count();
            bool opened=false,maybe=svc.query(r,opened),found=false;
            if(maybe){format49(key,r.id);auto b=Clock::now();found=querydb.lookup(key);backend_wall+=seconds(b);
                accepted++;wasted+=!member;db_miss+=member&&!found;if(!member&&found)throw std::runtime_error("negative DB hit");}
            fn+=member&&!maybe;open_queries+=opened;
            uint64_t done=std::chrono::duration_cast<std::chrono::nanoseconds>(Clock::now()-base).count();
            uint8_t bits=uint8_t(member)|(uint8_t(maybe)<<1)|(uint8_t(opened)<<2)|(uint8_t(found)<<3);
            if(fwrite(&bits,1,1,flags)!=1)throw std::runtime_error("flag write");
            if(requests%1024==0){std::array<uint64_t,4>row{requests,deadline,start,done};
                if(fwrite(row.data(),sizeof row,1,lat)!=1)throw std::runtime_error("latency write");}
            requests++;
        }
        query_cpu=thread_cpu49()-cpu;query_finish=seconds(base);
        if(fclose(flags)||fclose(lat))throw std::runtime_error("log close");
        for(auto f:member_files)fclose(f);
        CloseHandle(timer);
    }catch(...){reader_error=std::current_exception();abort=true;reader_ready=true;}});
    std::thread writer([&]{try{
        Input49<Raw49>in(inserts);Raw49 r{};Key key{};HANDLE timer=timer49();
        writer_ready=true;while(!go.load()&&!abort.load())std::this_thread::yield();double cpu=thread_cpu49();
        while(!abort.load()&&in.next(r)){
            wait49(base,500000000+inserted*5000000,timer);int64_t tick=margin49(model,r);auto h=hash49(r.id);
            {std::lock_guard<std::mutex>j(journal.mu);journal.append(r,h.shard);
                {std::lock_guard<std::mutex>lock(svc.mu);if(tick<=svc.cuts[h.shard])svc.add49(h);}
                // Cover before DB commit; journal lock prevents a clearing epoch
                // from starting before commit. Queries never wait on this lock.
                format49(key,r.id);writerdb.insert(key);}
            bool opened=false;insert_fn+=!svc.query(r,opened);format49(key,r.id);
            if(!writerdb.lookup(key))throw std::runtime_error("insert DB miss");
            inserted++;
        }
        writer_cpu=thread_cpu49()-cpu;writer_finish=seconds(base);CloseHandle(timer);
    }catch(...){writer_error=std::current_exception();abort=true;writer_ready=true;}});
    while((!reader_ready.load()||!writer_ready.load())&&!abort.load())std::this_thread::yield();
    querydb.reset_stats();writerdb.reset_stats();auto before_io=io();double cpu=cpu_seconds(),migration_cpu=thread_cpu49();base=Clock::now();go=true;
    uint64_t history_records=0,journal_records=0;double migration_wall=0;
    std::array<double,NS>begin{},end{};
    auto replay=[&](const std::string&path,uint64_t limit,int region){Input49<Raw49>in(path);Raw49 r{};
        while((limit==UINT64_MAX||in.count*sizeof(Raw49)<limit)&&in.next(r)){
            int64_t tick=margin49(model,r);auto h=hash49(r.id);
            if(region>=0&&h.shard!=uint32_t(region))throw std::runtime_error("replay shard");
            if(tick<=NEW49){std::lock_guard<std::mutex>lock(svc.mu);svc.add49(h);}}
        if(limit!=UINT64_MAX&&in.count*sizeof(Raw49)!=limit)throw std::runtime_error("journal prefix");
        if(limit==UINT64_MAX)history_records+=in.count;else journal_records+=in.count;
    };
    try{
        HANDLE timer=timer49();wait49(base,1000000000,timer);CloseHandle(timer);auto migration_start=Clock::now();double mc=thread_cpu49();
        if(mode=="full"){
            std::array<uint64_t,NS>limits;
            {std::lock_guard<std::mutex>j(journal.mu);std::lock_guard<std::mutex>lock(svc.mu);limits=journal.bytes;
                std::fill(svc.filter.bits.begin(),svc.filter.bits.end(),0);svc.cuts.fill(NEW49);svc.open.fill(true);begin.fill(seconds(base));}
            for(auto name:MEMBER49)replay(data+"/"+name+".bin",UINT64_MAX,-1);
            for(int s=0;s<NS;s++)replay(output+"/journal"+std::to_string(s)+".bin",limits[s],s);
            {std::lock_guard<std::mutex>lock(svc.mu);svc.open.fill(false);end.fill(seconds(base));}
        }else if(mode=="regions"){
            for(int s=0;s<NS;s++){uint64_t limit;
                {std::lock_guard<std::mutex>j(journal.mu);std::lock_guard<std::mutex>lock(svc.mu);limit=journal.bytes[s];
                    memset(svc.filter.bits.data()+s*BLOCK49,0,BLOCK49);svc.cuts[s]=NEW49;svc.open[s]=true;begin[s]=seconds(base);}
                replay(shards+"/shard"+std::to_string(s)+".bin",UINT64_MAX,s);
                replay(output+"/journal"+std::to_string(s)+".bin",limit,s);
                {std::lock_guard<std::mutex>lock(svc.mu);svc.open[s]=false;end[s]=seconds(base);}
            }
        }
        migration_wall=seconds(migration_start);migration_cpu=thread_cpu49()-mc;
    }catch(...){abort=true;reader.join();writer.join();throw;}
    writer.join();reader.join();if(writer_error)std::rethrow_exception(writer_error);if(reader_error)std::rethrow_exception(reader_error);
    double total_cpu=cpu_seconds()-cpu,total_wall=seconds(base);auto after_io=io();auto peak=memory();
    uint64_t final_fn=fn_cached49(svc,scores);
    {Input49<Raw49>in(inserts);Raw49 r{};while(in.next(r)){bool opened=false;final_fn+=!svc.query(r,opened);}}
    uint64_t worddiff=0;{FILE*f=fopen((output+"/reference.bin").c_str(),"rb");if(!f)throw std::runtime_error("reference read");
        for(auto b:svc.filter.bits){uint8_t expected;if(fread(&expected,1,1,f)!=1)throw std::runtime_error("reference length");worddiff+=b!=expected;}fclose(f);}
    writerdb.checkpoint();auto db_rows=writerdb.number("SELECT count(*) FROM members");
    if(requests!=count||inserted!=1028||fn||insert_fn||db_miss||final_fn||worddiff||db_rows!=3001028)throw std::runtime_error("online invariant");
    std::cout<<"{\"mode\":\""<<mode<<"\",\"horizon_seconds\":"<<horizon<<",\"requests\":"<<requests<<",\"member_queries\":"<<member_queries
        <<",\"accepted\":"<<accepted<<",\"wasted\":"<<wasted<<",\"open_queries\":"<<open_queries
        <<",\"online_fn\":"<<fn<<",\"backend_member_misses\":"<<db_miss<<",\"inserts\":"<<inserted<<",\"insert_fn\":"<<insert_fn
        <<",\"final_fn\":"<<final_fn<<",\"endpoint_byte_mismatch\":"<<worddiff<<",\"db_rows\":"<<db_rows
        <<",\"serving_cpu_seconds\":"<<total_cpu<<",\"serving_wall_seconds\":"<<total_wall<<",\"query_thread_cpu_seconds\":"<<query_cpu
        <<",\"writer_thread_cpu_seconds\":"<<writer_cpu<<",\"migration_thread_cpu_seconds\":"<<migration_cpu
        <<",\"migration_wall_seconds\":"<<migration_wall<<",\"query_finish_seconds\":"<<query_finish<<",\"writer_finish_seconds\":"<<writer_finish
        <<",\"backend_wall_sum_seconds\":"<<backend_wall<<",\"history_records\":"<<history_records<<",\"journal_replay_records\":"<<journal_records
        <<",\"history_read_bytes\":"<<history_records*sizeof(Raw49)<<",\"journal_append_bytes\":"<<inserted*sizeof(Raw49)
        <<",\"core_state_bytes\":"<<core<<",\"core_metadata_sizeof\":"<<sizeof(Live49)+sizeof(Model)
        <<",\"process_peak_working_set\":"<<peak.peak<<",\"job_peak_commit_bytes\":"<<commit49(job)
        <<",\"sqlite_cache_hits\":"<<querydb.status(SQLITE_DBSTATUS_CACHE_HIT)<<",\"sqlite_cache_misses\":"<<querydb.status(SQLITE_DBSTATUS_CACHE_MISS)
        <<",\"sqlite_requested_cache_kib_per_connection\":"<<cache_kib
        <<",\"sqlite_reader_cache_used\":"<<querydb.status(SQLITE_DBSTATUS_CACHE_USED)
        <<",\"sqlite_writer_cache_used\":"<<writerdb.status(SQLITE_DBSTATUS_CACHE_USED)
        <<",\"os_read_transfer_bytes\":"<<after_io.ReadTransferCount-before_io.ReadTransferCount
        <<",\"os_write_transfer_bytes\":"<<after_io.WriteTransferCount-before_io.WriteTransferCount
        <<",\"initialization_wall_seconds\":"<<prep_wall<<",\"initialization_cpu_seconds\":"<<prep_cost
        <<",\"region_begin_seconds\":[";for(int s=0;s<NS;s++)std::cout<<(s?",":"")<<begin[s];
    std::cout<<"],\"region_end_seconds\":[";for(int s=0;s<NS;s++)std::cout<<(s?",":"")<<end[s];std::cout<<"]}\n";
    CloseHandle(job);return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 2;}
