"""Unchanged Gama DP/allocator; disclosed fixed-partition integer controls."""
import json,math,time
from pathlib import Path
import numpy as np
import psutil
from full_cod_plbf_select import prList,MaxDivDP,ThresMaxDiv,OptimalFPR_M,ExpectedFPR,REPO,sha,rate
from full_cod_gplbf_hist_run import OUT,ROOT
SCALE=1<<44
def probability(count):
    count=np.array(count,dtype=np.int64);total=int(count.sum());assert total>0
    obj=prList.__new__(prList);obj.N=len(count);obj.thre_list=[j/len(count) for j in range(len(count)+1)]
    obj.pr=[0.,*(count/total).tolist()];obj.accPr=np.r_[0.,np.cumsum(count/total)].tolist();assert abs(obj.accPr[-1]-1)<1e-8
    return obj
def hist(name):return np.fromfile(OUT/f'hist/{name}.hist',dtype='<u8',offset=16).astype(np.int64).reshape(48,100)
def integer_layout(indices,f,n,q,cuts,available):
    pieces=[]
    for i,(ni,qi) in enumerate(zip(n,q)):
        ni=int(ni);qi=int(qi);fi=f[i+1]
        byte=0 if ni==0 or fi>=1 else math.floor(-ni*math.log(fi)/(math.log(2)**2)/64)*8
        pieces.append(dict(upper=int(cuts[indices[i+1]-1]),n=ni,q=qi,bytes=byte))
    assert 0<=sum(p['bytes'] for p in pieces)<=available
    while sum(p['bytes'] for p in pieces)+8<=available:
        gains=[(p['q']*(rate(p['n'],p['bytes'])[0]-rate(p['n'],p['bytes']+8)[0]),-i) for i,p in enumerate(pieces) if p['n'] and p['bytes']]
        if not gains or max(gains)[0]<=0:break
        pieces[-max(gains)[1]]['bytes']+=8
    for p in pieces:p['estimated_bf_fpr'],p['hashes']=rate(p['n'],p['bytes'])
    return pieces,sum(p['q']*p['estimated_bf_fpr'] for p in pieces)/sum(q)
def main():
    assert json.loads((OUT/'hist-verification.json').read_text())['returncode']==0
    assert not (OUT/'selection-profile.json').exists();(OUT/'descriptors').mkdir()
    negatives=hist('validation');initial=hist('initial');current=initial+hist('early')+hist('late');winners=[];ideal_winners=[];start=time.perf_counter();cpu=time.process_time();count=0
    cuts100=np.array([math.floor(math.log((j/100)/(1-j/100))*SCALE) for j in range(1,100)]+[(1<<63)-1],dtype=np.int64)
    with (OUT/'candidates.jsonl').open('x') as log:
        for stage,positive in ((0,initial),(2,current)):
            stage_cpu=time.process_time();stage_start=time.perf_counter()
            for d in range(1,49):
                available=(262144-2048-700*d)//8*8;options=[];original=[]
                for N,K in ((50,5),(100,8)):
                    factor=100//N;pos=positive[d-1].reshape(N,factor).sum(axis=1);neg=negatives[d-1].reshape(N,factor).sum(axis=1);cuts=cuts100[factor-1::factor]
                    g=probability(pos);h=probability(neg);_,pre=MaxDivDP(g,h,N,K)
                    for tail in range(K,N+1):
                        t=ThresMaxDiv(pre,tail,K,g.thre_list)
                        if t is None:continue
                        indices=[int(round(x*N)) for x in t];n=[int(pos[indices[i]:indices[i+1]].sum()) for i in range(K)];q=[int(neg[indices[i]:indices[i+1]].sum()) for i in range(K)]
                        f=OptimalFPR_M(g,h,t,float(available*8),K,int(sum(n)))
                        ideal=float(ExpectedFPR(g,h,t,f,sum(n)))
                        for drop in range(-1,K):
                            if drop==-1:allocation=f
                            else:
                                nc=n.copy();qc=q.copy();nc[drop]=qc[drop]=0
                                if not sum(nc) or not sum(qc):continue
                                gc=probability(nc);hc=probability(qc)
                                # Keep the partition, normalize remaining densities; author allocator unchanged.
                                allocation=OptimalFPR_M(gc,hc,gc.thre_list,float(available*8),K,sum(nc));allocation[drop+1]=1.
                            pieces,estimate=integer_layout(indices,allocation,n,q,cuts,available)
                            row=dict(stage=stage,depth=d,N=N,groups=K,tail_bin=tail,drop_bucket=drop,ideal_author_fpr=ideal,
                                estimated_fpr=estimate,bf_bytes=sum(p['bytes'] for p in pieces),state_bytes=2048+700*d+sum(p['bytes'] for p in pieces),unused_bytes=available-sum(p['bytes'] for p in pieces))
                            log.write(json.dumps(row)+'\n');count+=1;option={**row,'pieces':pieces};options.append(option)
                            if drop==-1:original.append(option)
                assert options,(stage,d)
                winner=min(options,key=lambda r:(r['estimated_fpr'],r['N'],r['drop_bucket'],r['tail_bin']))
                ideal_winners.append(min(original,key=lambda r:(r['ideal_author_fpr'],r['N'],r['tail_bin'])))
                descriptor=OUT/f'descriptors/{stage}-{d}.txt';descriptor.write_text('\n'.join([str(winner['groups'])]+[f'{p["upper"]} {p["bytes"]} {p["hashes"]} {p["n"]}' for p in winner['pieces']])+'\n')
                winner={**winner,'descriptor':str(descriptor),'descriptor_sha256':sha(descriptor)};winners.append(winner)
                (OUT/'selected-layouts.json').write_text(json.dumps(winners,indent=2))
                if d%8==0:print('PLBF stage',stage,'depth',d,'estimate',winner['estimated_fpr'],'grid',winner['N'],'drop',winner['drop_bucket'],flush=True)
            (OUT/f'selection-stage-{stage}.json').write_text(json.dumps(dict(stage=stage,cpu_seconds=time.process_time()-stage_cpu,wall_seconds=time.perf_counter()-stage_start),indent=2))
    (OUT/'author-continuous-winners.json').write_text(json.dumps(ideal_winners,indent=2))
    sources={str(p):sha(p) for p in [Path(__file__),ROOT/'plan/full-cod-gplbf-protocol.md',REPO/'plbf/utils/ThresMaxDivDP.py',REPO/'plbf/utils/OptimalFPR_M.py',REPO/'plbf/utils/calc_DPKL.py',REPO/'plbf/utils/prList.py',REPO/'plbf/utils/ExpectedFPR.py']}
    profile=dict(returncode=0,cpu_seconds=time.process_time()-cpu,wall_seconds=time.perf_counter()-start,peak_working_set=psutil.Process().memory_info().peak_wset,candidates=count,layouts=len(winners),sources=sources,scope='fixed48 tree family;unchanged author optimizer;drop-one integer adaptation;no independent-test selection')
    (OUT/'selection-profile.json').write_text(json.dumps(profile,indent=2));print('96 layouts frozen; candidates',count,flush=True)
if __name__=='__main__':main()
